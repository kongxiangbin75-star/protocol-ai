import React, { useState, useEffect } from 'react';
import { Project, ApiConfig, ClinicalDocument, CustomTemplate, DocNode } from './types';
import { StorageService } from './services/storage';
import { DEFAULT_GEMINI_MODEL, TEMPLATES } from './constants';
import Dashboard from './components/Dashboard';
import KnowledgeBase from './components/KnowledgeBase';
import ProjectWizard from './components/ProjectWizard';
import ProjectHub from './components/ProjectHub';
import Workspace from './components/Workspace';
import SettingsModal from './components/SettingsModal';
import TemplateManager from './components/TemplateManager';

type ViewState = 'dashboard' | 'kb' | 'templates' | 'wizard' | 'project-hub' | 'workspace';

export default function App() {
  const [view, setView] = useState<ViewState>('dashboard');
  const [projects, setProjects] = useState<Project[]>([]);
  const [customTemplates, setCustomTemplates] = useState<CustomTemplate[]>([]);
  const [currentProject, setCurrentProject] = useState<Project | null>(null);
  const [currentDocument, setCurrentDocument] = useState<ClinicalDocument | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [apiConfig, setApiConfig] = useState<ApiConfig>({ apiKey: '', model: DEFAULT_GEMINI_MODEL, provider: 'Gemini' });

  useEffect(() => {
    const init = async () => {
      const p = await StorageService.getProjects();
      setProjects(p);
      const t = await StorageService.getCustomTemplates();
      setCustomTemplates(t);
      const s = StorageService.getSettings();
      if (s) setApiConfig(s);
    };
    init();
  }, [view]);

  // Helper to extract default content from template structure
  const extractDefaultData = (nodes: DocNode[]): Record<string, string> => {
    let data: Record<string, string> = {};
    const traverse = (n: DocNode[]) => {
      n.forEach(node => {
        if (node.defaultContent) {
          data[node.id] = node.defaultContent;
        }
        if (node.children) traverse(node.children);
      });
    };
    traverse(nodes);
    return data;
  };

  const handleCreateProject = async (data: any) => {
    // Determine initial document structure
    let initialDocStructure = TEMPLATES['protocol'].structure;
    let initialDocTitle = TEMPLATES['protocol'].title;

    // Check if a custom template was selected (ProjectWizard passes selectedTemplateId in data)
    if (data.selectedTemplateId) {
      const customTemplate = customTemplates.find(t => t.id === data.selectedTemplateId);
      if (customTemplate) {
        initialDocStructure = customTemplate.structure;
        initialDocTitle = customTemplate.name;
      }
    }

    // Pre-fill data if template has default content
    const initialData = extractDefaultData(initialDocStructure);

    const defaultProtocol: ClinicalDocument = {
      id: Math.random().toString(36).substr(2, 9),
      title: initialDocTitle,
      type: 'protocol',
      status: 'draft',
      docTree: JSON.parse(JSON.stringify(initialDocStructure)),
      docData: initialData, // Use extracted defaults
      versions: [],
      updatedAt: Date.now()
    };

    const newProject: Project = {
      id: Math.random().toString(36).substr(2, 9),
      projectName: data.projectName,
      variables: data.variables,
      documents: [defaultProtocol], // Start with one doc
      activityLog: [],
      createdAt: Date.now(),
      updatedAt: Date.now()
    };

    await StorageService.saveProject(newProject);
    setCurrentProject(newProject);
    setView('project-hub');
  };

  const handleUpdateProject = async (updatedProject: Project) => {
      await StorageService.saveProject(updatedProject);
      setCurrentProject(updatedProject);
  };

  const handleDeleteProject = async (id: string) => {
    if (!confirm("Are you sure you want to delete this project? This action cannot be undone.")) return;
    await StorageService.deleteProject(id);
    const p = await StorageService.getProjects();
    setProjects(p);
  };

  const handleUpdateDocument = async (updatedDoc: ClinicalDocument) => {
    if (!currentProject) return;
    const updatedDocs = currentProject.documents.map(d => d.id === updatedDoc.id ? updatedDoc : d);
    const updatedProject = { ...currentProject, documents: updatedDocs, updatedAt: Date.now() };
    await StorageService.saveProject(updatedProject);
    setCurrentProject(updatedProject);
    setCurrentDocument(updatedDoc);
  };

  const handleUpdateSettings = (cfg: ApiConfig) => {
    setApiConfig(cfg);
    StorageService.saveSettings(cfg);
  };

  return (
    <>
      {showSettings && <SettingsModal config={apiConfig} onSave={handleUpdateSettings} onClose={() => setShowSettings(false)} />}

      {view === 'dashboard' && (
        <Dashboard 
          projects={projects}
          onCreateProject={() => setView('wizard')}
          onOpenProject={(p) => { setCurrentProject(p); setView('project-hub'); }}
          onDeleteProject={handleDeleteProject}
          onOpenKB={() => setView('kb')}
          onOpenTemplates={() => setView('templates')}
          onOpenSettings={() => setShowSettings(true)}
        />
      )}

      {view === 'kb' && <KnowledgeBase onBack={() => setView('dashboard')} />}
      
      {view === 'templates' && <TemplateManager onBack={() => setView('dashboard')} apiConfig={apiConfig} />}

      {view === 'wizard' && (
        <ProjectWizard 
          onCancel={() => setView('dashboard')} 
          onComplete={handleCreateProject} 
          apiConfig={apiConfig}
          customTemplates={customTemplates} 
        />
      )}

      {view === 'project-hub' && currentProject && (
          <ProjectHub 
            project={currentProject} 
            customTemplates={customTemplates}
            onBack={() => setView('dashboard')}
            onOpenDocument={(doc) => { setCurrentDocument(doc); setView('workspace'); }}
            onUpdateProject={handleUpdateProject}
          />
      )}

      {view === 'workspace' && currentProject && currentDocument && (
        <Workspace 
          project={currentProject} 
          initialDoc={currentDocument} 
          onBack={() => setView('project-hub')}
          apiConfig={apiConfig}
          onUpdateDocument={handleUpdateDocument}
        />
      )}
    </>
  );
}