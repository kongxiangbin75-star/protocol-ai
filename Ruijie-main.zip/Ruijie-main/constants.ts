
import { DocNode, ClinicalVariables } from './types';

export const DEFAULT_GEMINI_MODEL = "gemini-3-flash-preview";

export const AVAILABLE_MODELS = [
  // Gemini Models
  { id: "gemini-3-flash-preview", name: "Gemini 3 Flash (Fast & Efficient)", description: "Best for quick drafting and simple tasks.", provider: 'Gemini' },
  { id: "gemini-3.1-flash-lite-preview", name: "Gemini 3.1 Flash Lite", description: "Lightweight and fast for high-volume tasks.", provider: 'Gemini' },
  { id: "gemini-3.1-pro-preview", name: "Gemini 3.1 Pro (Advanced Reasoning)", description: "Best for complex clinical reasoning and consistency checks.", provider: 'Gemini' },
  { id: "gemini-flash-latest", name: "Gemini Flash Latest", description: "The most up-to-date flash model.", provider: 'Gemini' },
  
  // Qwen Models (Alibaba)
  { id: "qwen-max", name: "Qwen Max", description: "Alibaba's most powerful model.", provider: 'Qwen' },
  { id: "qwen-plus", name: "Qwen Plus", description: "Balanced performance and speed.", provider: 'Qwen' },
  { id: "qwen-turbo", name: "Qwen Turbo", description: "Fast and cost-effective.", provider: 'Qwen' },

  // Doubao Models (ByteDance)
  { id: "doubao-pro-32k", name: "Doubao Pro (32k)", description: "ByteDance's professional model with 32k context.", provider: 'Doubao' },
  { id: "doubao-lite-32k", name: "Doubao Lite (32k)", description: "Lightweight version of Doubao.", provider: 'Doubao' },
];

export const PROVIDER_DEFAULTS: Record<string, { baseUrl: string, defaultModel: string }> = {
  'Gemini': { baseUrl: '', defaultModel: 'gemini-3-flash-preview' },
  'Qwen': { baseUrl: 'https://dashscope.aliyuncs.com/compatible-mode/v1', defaultModel: 'qwen-plus' },
  'Doubao': { baseUrl: 'https://ark.cn-beijing.volces.com/api/v3', defaultModel: 'doubao-pro-32k' },
  'OpenAI-Compatible': { baseUrl: '', defaultModel: '' }
};

export const INITIAL_VARIABLES: ClinicalVariables = {
  fullTitle: "", briefTitle: "", trialId: "", protocolVersionDate: "", studyPhase: "", 
  trialDesign: "", objectives: "", studyEndpoints: "", inclusionCriteria: "", 
  exclusionCriteria: "", sampleSize: "", targetPopulation: "", investigationalProduct: "", 
  comparator: "", routesOfAdministration: "", statisticalAnalysis: "", duration: ""
};

// --- TRIAL BINDER ---
const PROTOCOL_STRUCTURE: DocNode[] = [
  { id: "1", title: "1. SYNOPSIS", type: "section", children: [] },
  { id: "2", title: "2. INTRODUCTION", type: "section", children: [] },
  { id: "3", title: "3. OBJECTIVES", type: "section", children: [] },
  { id: "4", title: "4. STUDY DESIGN", type: "section", children: [] },
  { id: "5", title: "5. SELECTION OF PARTICIPANTS", type: "section", children: [
    { id: "5.1", title: "Inclusion Criteria", type: "text" },
    { id: "5.2", title: "Exclusion Criteria", type: "text" }
  ]},
  { id: "6", title: "6. INTERVENTIONS", type: "section", children: [] },
  { id: "7", title: "7. ASSESSMENT SCHEDULE", type: "section", children: [] },
  { id: "8", title: "8. STATISTICS", type: "section", children: [] }
];

const IB_STRUCTURE: DocNode[] = [
  { id: "1", title: "1. SUMMARY", type: "section", children: [] },
  { id: "2", title: "2. INTRODUCTION", type: "section", children: [] },
  { id: "3", title: "3. NONCLINICAL STUDIES", type: "section", children: [] },
  { id: "4", title: "4. EFFECTS IN HUMANS", type: "section", children: [] },
  { id: "5", title: "5. SUMMARY OF DATA", type: "section", children: [] }
];

const WORKSHEET_STRUCTURE: DocNode[] = [
  { id: "1", title: "VISIT 1 (SCREENING)", type: "section", children: [
    { id: "1.1", title: "Demographics", type: "text" },
    { id: "1.2", title: "Vitals", type: "text" },
    { id: "1.3", title: "I/E Criteria Checklist", type: "text" }
  ]},
  { id: "2", title: "VISIT 2 (BASELINE)", type: "section", children: [] },
  { id: "3", title: "ADVERSE EVENT LOG", type: "section", children: [] }
];

// --- SUBJECT BINDER ---
const ICF_STRUCTURE: DocNode[] = [
  { id: "1", title: "1. KEY INFORMATION", type: "section", children: [] },
  { id: "2", title: "2. PURPOSE OF STUDY", type: "section", children: [] },
  { id: "3", title: "3. PROCEDURES", type: "section", children: [] },
  { id: "4", title: "4. RISKS AND DISCOMFORTS", type: "section", children: [] },
  { id: "5", title: "5. BENEFITS", type: "section", children: [] },
  { id: "6", title: "6. VOLUNTARY PARTICIPATION", type: "section", children: [] },
  { id: "7", title: "7. CONFIDENTIALITY", type: "section", children: [] }
];

const DIARY_STRUCTURE: DocNode[] = [
  { id: "1", title: "INSTRUCTIONS", type: "section", children: [] },
  { id: "2", title: "DAILY ENTRY LOG", type: "section", children: [
    { id: "2.1", title: "Morning Dose", type: "text" },
    { id: "2.2", title: "Evening Dose", type: "text" },
    { id: "2.3", title: "Symptoms", type: "text" }
  ]},
  { id: "3", title: "EMERGENCY CONTACTS", type: "section", children: [] }
];

const PARTICIPATION_CARD_STRUCTURE: DocNode[] = [
  { id: "1", title: "FRONT: PATIENT ID", type: "section", children: [] },
  { id: "2", title: "BACK: SCHEDULE", type: "section", children: [] }
];

const AD_STRUCTURE: DocNode[] = [
  { id: "1", title: "HEADLINE", type: "section", children: [] },
  { id: "2", title: "BODY COPY", type: "section", children: [] },
  { id: "3", title: "ELIGIBILITY BULLETS", type: "section", children: [] },
  { id: "4", title: "CALL TO ACTION", type: "section", children: [] }
];

// --- OPERATION BINDER ---
const SAP_STRUCTURE: DocNode[] = [
  { id: "1", title: "1. INTRODUCTION", type: "section", children: [] },
  { id: "2", title: "2. OBJECTIVES", type: "section", children: [] },
  { id: "3", title: "3. ENDPOINTS", type: "section", children: [] },
  { id: "4", title: "4. ANALYSIS SETS", type: "section", children: [] },
  { id: "5", title: "5. STATISTICAL METHODS", type: "section", children: [] }
];

const DMP_STRUCTURE: DocNode[] = [
  { id: "1", title: "1. DATAFLOW", type: "section", children: [] },
  { id: "2", title: "2. DATABASE DESIGN", type: "section", children: [] },
  { id: "3", title: "3. VALIDATION RULES", type: "section", children: [] }
];

const CMP_STRUCTURE: DocNode[] = [
  { id: "1", title: "1. VISIT SCHEDULE", type: "section", children: [] },
  { id: "2", title: "2. SDV PLAN", type: "section", children: [] },
  { id: "3", title: "3. PHARMACY MONITORING", type: "section", children: [] }
];

const MANUAL_STRUCTURE: DocNode[] = [
  { id: "1", title: "1. LAB PROCESSING", type: "section", children: [] },
  { id: "2", title: "2. IP HANDLING", type: "section", children: [] },
  { id: "3", title: "3. SYSTEM ACCESS", type: "section", children: [] }
];

const CSR_STRUCTURE: DocNode[] = [
  { id: "1", title: "1. SYNOPSIS", type: "section", children: [] },
  { id: "2", title: "2. RESULTS", type: "section", children: [] },
  { id: "3", title: "3. CONCLUSIONS", type: "section", children: [] }
];


export const TEMPLATES = {
  // Trial Binder
  'protocol': { title: "Clinical Protocol", structure: PROTOCOL_STRUCTURE, color: "bg-blue-600", icon: "book" },
  'ib': { title: "Investigator's Brochure", structure: IB_STRUCTURE, color: "bg-blue-500", icon: "file-text" },
  'worksheet': { title: "Source Worksheet", structure: WORKSHEET_STRUCTURE, color: "bg-blue-400", icon: "clipboard" },
  
  // Subject Binder
  'icf': { title: "Informed Consent Form", structure: ICF_STRUCTURE, color: "bg-emerald-600", icon: "user-check" },
  'diary': { title: "Patient Diary", structure: DIARY_STRUCTURE, color: "bg-emerald-500", icon: "calendar" },
  'participation_card': { title: "Participation Card", structure: PARTICIPATION_CARD_STRUCTURE, color: "bg-emerald-400", icon: "credit-card" },
  'ad': { title: "Recruitment Ad", structure: AD_STRUCTURE, color: "bg-emerald-300", icon: "megaphone" },

  // Operation Binder
  'sap': { title: "Statistical Analysis Plan", structure: SAP_STRUCTURE, color: "bg-slate-600", icon: "bar-chart" },
  'dmp': { title: "Data Management Plan", structure: DMP_STRUCTURE, color: "bg-slate-500", icon: "database" },
  'cmp': { title: "Clinical Monitoring Plan", structure: CMP_STRUCTURE, color: "bg-slate-400", icon: "eye" },
  'manual': { title: "Study Manual", structure: MANUAL_STRUCTURE, color: "bg-slate-500", icon: "settings" },
  'csr': { title: "Clinical Study Report", structure: CSR_STRUCTURE, color: "bg-purple-600", icon: "check-circle" },
};
