import { GoogleGenAI, Type } from "@google/genai";
import { ApiConfig, ClinicalVariables, DocNode } from "../types";
import { DEFAULT_GEMINI_MODEL } from "../constants";

// Explicitly use process.env.API_KEY as per Google GenAI Guidelines
const getGeminiClient = (apiKey?: string) => {
  const key = apiKey || process.env.API_KEY;
  if (!key) {
    console.warn("Gemini API Key is missing.");
    return null;
  }
  return new GoogleGenAI({ apiKey: key });
};

const callAI = async (
  config: ApiConfig, 
  prompt: string, 
  options: { json?: boolean, schema?: any } = {}
): Promise<string> => {
  if (!config.provider || config.provider === 'Gemini') {
    const client = getGeminiClient(config.apiKey);
    if (!client) throw new Error("Gemini API Key missing.");
    
    const response = await client.models.generateContent({
      model: config.model || DEFAULT_GEMINI_MODEL,
      contents: prompt,
      config: options.json ? {
        responseMimeType: "application/json",
        responseSchema: options.schema
      } : undefined
    });
    return response.text || "";
  } else {
    // OpenAI Compatible (Qwen, Doubao, etc.)
    const baseUrl = config.baseUrl || 'https://api.openai.com/v1';
    const response = await fetch(`${baseUrl}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${config.apiKey}`
      },
      body: JSON.stringify({
        model: config.model,
        messages: [{ role: 'user', content: prompt }],
        response_format: options.json ? { type: 'json_object' } : undefined
      })
    });

    if (!response.ok) {
      const err = await response.text();
      throw new Error(`AI Provider Error (${config.provider}): ${err}`);
    }

    const data = await response.json();
    return data.choices[0].message.content || "";
  }
};

export const extractVariablesFromText = async (
  config: ApiConfig,
  text: string
): Promise<Partial<ClinicalVariables>> => {
  const prompt = `
    You are an expert Clinical Data Manager. 
    Extract the following clinical trial parameters from the provided text.
    Return the result as a JSON object.
    If a field is not found, use "Not specified".
    
    Fields to extract:
    fullTitle, briefTitle, trialId, protocolVersionDate, studyPhase, 
    trialDesign, objectives, studyEndpoints, inclusionCriteria, 
    exclusionCriteria, sampleSize, targetPopulation, investigationalProduct, 
    comparator, routesOfAdministration, statisticalAnalysis, duration.

    Text Context:
    ${text.substring(0, 500000)}
  `;

  try {
    const result = await callAI(config, prompt, {
      json: true,
      schema: {
        type: Type.OBJECT,
        properties: {
           fullTitle: { type: Type.STRING },
           briefTitle: { type: Type.STRING },
           trialId: { type: Type.STRING },
           protocolVersionDate: { type: Type.STRING },
           studyPhase: { type: Type.STRING },
           trialDesign: { type: Type.STRING },
           objectives: { type: Type.STRING },
           studyEndpoints: { type: Type.STRING },
           inclusionCriteria: { type: Type.STRING },
           exclusionCriteria: { type: Type.STRING },
           sampleSize: { type: Type.STRING },
           targetPopulation: { type: Type.STRING },
           investigationalProduct: { type: Type.STRING },
           comparator: { type: Type.STRING },
           routesOfAdministration: { type: Type.STRING },
           statisticalAnalysis: { type: Type.STRING },
           duration: { type: Type.STRING }
        }
      }
    });

    return JSON.parse(result || "{}");
  } catch (error) {
    console.error("AI Extraction Error:", error);
    throw error;
  }
};

export const extractTemplateStructure = async (
  config: ApiConfig,
  text: string
): Promise<DocNode[]> => {
  const prompt = `
    Analyze the provided document text and extract the hierarchical Table of Contents (Structure).
    
    CRITICAL INSTRUCTION:
    For each section, extract the "General Content" or "Boilerplate Text" found in that section. 
    We want to create a reusable template. 
    - If the section contains specific study data (like "50mg of Aspirin"), generalized it to placeholders (e.g., "[Insert Dosage] of [Investigational Product]").
    - Capture the tone and structure of the paragraph in the 'defaultContent' field.
    
    Return a JSON array of 'DocNode' objects.
    DocNode interface: { id: string, title: string, type: 'section' | 'text', defaultContent?: string, children?: DocNode[] }

    Rules:
    - 'section': Contains sub-sections.
    - 'text': Leaf node for content.
    - 'title': Clean section name (e.g., "1. Introduction").
    - 'defaultContent': The generalized text content of the section.
    - 'id': Generate unique alphanumeric string.
    - Capture up to 4 levels of depth.

    Text Context:
    ${text.substring(0, 300000)}
  `;

  try {
    const result = await callAI(config, prompt, {
      json: true,
      schema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            id: { type: Type.STRING },
            title: { type: Type.STRING },
            type: { type: Type.STRING },
            defaultContent: { type: Type.STRING },
            children: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { id: { type: Type.STRING }, title: { type: Type.STRING }, type: { type: Type.STRING }, defaultContent: { type: Type.STRING } } } }
          },
          required: ["id", "title", "type"]
        }
      }
    });

    return JSON.parse(result || "[]");
  } catch (error) {
    console.error("Template Extraction Error:", error);
    throw new Error("Failed to extract template structure. " + (error as Error).message);
  }
};

export const generateSectionContent = async (
  config: ApiConfig,
  sectionTitle: string,
  projectName: string,
  variables: ClinicalVariables,
  writingStyle: string,
  kbContext: string,
  documentContext: string = ""
): Promise<string> => {
  const prompt = `
    Write full content for the section: "${sectionTitle}" of "${projectName}".
    
    Variables: ${JSON.stringify(variables)}
    Style: ${writingStyle}
    References: ${kbContext}
    Doc Context: ${documentContext.substring(0, 50000)}
    
    INSTRUCTIONS:
    - Format output as HTML (NOT Markdown). 
    - Use <b> for bold, <i> for italic, <ul>/<li> for lists.
    - Use HTML <table> for data presentation (e.g., Schedule of Assessments). Style the table with 'border-collapse: collapse; width: 100%; border: 1px solid #000;'.
    - If a Figure is needed, insert a placeholder: <div style="background:#f0f0f0; border:1px dashed #ccc; padding:20px; text-align:center; margin: 10px 0;">[FIGURE: Description]</div>
    - Be professional and compliant with GCP.
  `;

  try {
    const result = await callAI(config, prompt);
    return result || "Failed to generate.";
  } catch (error) {
    console.error("Generation Error:", error);
    return `Error: ${(error as Error).message}`;
  }
};

// NEW: Contextual Refinement Function
export const refineText = async (
  config: ApiConfig,
  selectedText: string,
  instruction: string
): Promise<string> => {
  const prompt = `
    You are an expert Medical Writer.
    Task: ${instruction}
    
    Input Text (HTML):
    "${selectedText}"

    Return ONLY the rewritten HTML. Keep tables and formatting if relevant.
  `;

  try {
    const result = await callAI(config, prompt);
    return result?.trim() || selectedText;
  } catch (error) {
    console.error("Refinement Error:", error);
    return selectedText;
  }
};

export const critiqueSectionContent = async (
  config: ApiConfig,
  sectionTitle: string,
  currentContent: string,
  variables: ClinicalVariables,
  mode: 'gcp' | 'consistency' | 'clarity'
): Promise<string> => {
  let systemInstruction = "";
  if (mode === 'gcp') systemInstruction = "You are a Regulatory Affairs auditor. Check for ICH-GCP compliance issues.";
  if (mode === 'consistency') systemInstruction = "You are a Medical Writer. Check for consistency with the study variables provided.";
  if (mode === 'clarity') systemInstruction = "You are a Copy Editor. Check for scientific clarity, passive voice overuse, and readability.";

  const prompt = `
    ${systemInstruction}
    
    Review the following section ("${sectionTitle}"):
    ${currentContent}

    Study Context (Source of Truth):
    ${JSON.stringify(variables, null, 2)}

    Output Format:
    Provide a bulleted list of issues or improvements. If it is good, say "No significant issues found."
    Do NOT rewrite the whole section, just list critique points.
  `;

  try {
    const result = await callAI(config, prompt);
    return result || "No critique generated.";
  } catch (error) {
    console.error("Critique Error:", error);
    return `Error: ${(error as Error).message}`;
  }
};