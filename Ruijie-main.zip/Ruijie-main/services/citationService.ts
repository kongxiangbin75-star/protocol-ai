import { Citation } from '../types';

export const CitationService = {
  async searchPubMed(query: string): Promise<Citation[]> {
    try {
      const searchUrl = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&term=${encodeURIComponent(query)}&retmode=json&retmax=10`;
      const searchRes = await fetch(searchUrl);
      const searchData = await searchRes.json();
      
      const ids = searchData.esearchresult?.idlist || [];
      if (ids.length === 0) return [];

      const summaryUrl = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=pubmed&id=${ids.join(',')}&retmode=json`;
      const summaryRes = await fetch(summaryUrl);
      const summaryData = await summaryRes.json();
      
      const results: Citation[] = [];
      ids.forEach((id: string) => {
        const item = summaryData.result[id];
        if (item) {
          results.push({
            id: `PMID:${id}`,
            source: 'pubmed',
            title: item.title,
            authors: item.authors?.map((a: any) => a.name) || [],
            journal: item.fulljournalname || item.source,
            year: item.pubdate?.split(' ')[0] || '',
            url: `https://pubmed.ncbi.nlm.nih.gov/${id}/`,
            doi: item.elocationid?.replace('doi: ', '') || '',
          });
        }
      });
      return results;
    } catch (error) {
      console.error('PubMed search error:', error);
      return [];
    }
  },

  async searchClinicalTrials(query: string): Promise<Citation[]> {
    try {
      const url = `https://clinicaltrials.gov/api/v2/studies?query.term=${encodeURIComponent(query)}&pageSize=10`;
      const res = await fetch(url);
      const data = await res.json();
      
      const results: Citation[] = (data.studies || []).map((study: any) => {
        const info = study.protocolSection?.identificationModule;
        const status = study.protocolSection?.statusModule?.overallStatus;
        const nctId = info?.nctId;
        
        return {
          id: nctId || Math.random().toString(),
          source: 'clinicaltrials',
          title: info?.officialTitle || info?.briefTitle || 'Untitled Study',
          authors: [info?.organization?.fullName || 'N/A'],
          journal: `ClinicalTrials.gov (${status || 'Unknown Status'})`,
          year: study.protocolSection?.statusModule?.startDateStruct?.date?.split('-')[0] || '',
          url: `https://clinicaltrials.gov/study/${nctId}`,
        };
      });
      return results;
    } catch (error) {
      console.error('ClinicalTrials search error:', error);
      return [];
    }
  }
};
