// Helper to access window libraries
declare global {
  interface Window {
    mammoth: any;
    pdfjsLib: any;
  }
}

export const parseFile = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    if (file.name.endsWith('.docx')) {
      reader.onload = (evt) => {
        if (!window.mammoth) return reject(new Error("Mammoth library not loaded."));
        const arrayBuffer = evt.target?.result as ArrayBuffer;
        window.mammoth.extractRawText({ arrayBuffer })
          .then((r: any) => r.value ? resolve(r.value) : reject(new Error("Empty DOCX")))
          .catch((err: Error) => reject(new Error("Mammoth error: " + err.message)));
      };
      reader.readAsArrayBuffer(file);
    } else if (file.type === 'application/pdf') {
      reader.onload = async (evt) => {
        try {
          if (!window.pdfjsLib) return reject(new Error("PDF.js library not loaded."));
          const arrayBuffer = evt.target?.result as Uint8Array;
          const pdf = await window.pdfjsLib.getDocument(arrayBuffer).promise;
          let text = "";
          const maxPages = Math.min(pdf.numPages, 20); // Limit parsing for performance
          
          for (let i = 1; i <= maxPages; i++) {
            const page = await pdf.getPage(i);
            const content = await page.getTextContent();
            text += content.items.map((s: any) => s.str).join(' ') + "\n";
          }
          resolve(text);
        } catch (e: any) {
          reject(e);
        }
      };
      reader.readAsArrayBuffer(file);
    } else {
      reject(new Error("Unsupported file type. Please upload .docx or .pdf"));
    }
  });
};