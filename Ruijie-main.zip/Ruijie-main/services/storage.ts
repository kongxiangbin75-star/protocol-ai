
import { Project, KBItem, CustomTemplate } from '../types';
import { DEFAULT_GEMINI_MODEL } from '../constants';

const STORAGE_KEYS = {
  PROJECTS: 'clinical_studio_projects',
  KB: 'clinical_studio_kb',
  SETTINGS: 'clinical_studio_settings',
  TEMPLATES: 'clinical_studio_templates'
};

// Helper to simulate delay for realism
const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

export const StorageService = {
  getProjects: async (): Promise<Project[]> => {
    await delay(200);
    const data = localStorage.getItem(STORAGE_KEYS.PROJECTS);
    return data ? JSON.parse(data) : [];
  },

  saveProject: async (project: Project): Promise<void> => {
    await delay(300);
    const projects = await StorageService.getProjects();
    const index = projects.findIndex(p => p.id === project.id);
    if (index >= 0) {
      projects[index] = project;
    } else {
      projects.unshift(project);
    }
    localStorage.setItem(STORAGE_KEYS.PROJECTS, JSON.stringify(projects));
  },

  deleteProject: async (id: string): Promise<void> => {
    await delay(300);
    const projects = await StorageService.getProjects();
    const filtered = projects.filter(p => p.id !== id);
    localStorage.setItem(STORAGE_KEYS.PROJECTS, JSON.stringify(filtered));
  },

  getKBItems: async (): Promise<KBItem[]> => {
    await delay(200);
    const data = localStorage.getItem(STORAGE_KEYS.KB);
    return data ? JSON.parse(data) : [];
  },

  addKBItem: async (item: KBItem): Promise<void> => {
    await delay(300);
    const items = await StorageService.getKBItems();
    items.push(item);
    localStorage.setItem(STORAGE_KEYS.KB, JSON.stringify(items));
  },

  deleteKBItem: async (id: string): Promise<void> => {
    const items = await StorageService.getKBItems();
    const filtered = items.filter(i => i.id !== id);
    localStorage.setItem(STORAGE_KEYS.KB, JSON.stringify(filtered));
  },

  getCustomTemplates: async (): Promise<CustomTemplate[]> => {
    await delay(200);
    const data = localStorage.getItem(STORAGE_KEYS.TEMPLATES);
    return data ? JSON.parse(data) : [];
  },

  saveCustomTemplate: async (template: CustomTemplate): Promise<void> => {
    await delay(300);
    const templates = await StorageService.getCustomTemplates();
    templates.push(template);
    localStorage.setItem(STORAGE_KEYS.TEMPLATES, JSON.stringify(templates));
  },

  deleteCustomTemplate: async (id: string): Promise<void> => {
    const templates = await StorageService.getCustomTemplates();
    const filtered = templates.filter(t => t.id !== id);
    localStorage.setItem(STORAGE_KEYS.TEMPLATES, JSON.stringify(filtered));
  },

  getSettings: () => {
    const data = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    return data ? JSON.parse(data) : { apiKey: "", model: DEFAULT_GEMINI_MODEL, provider: "Gemini" };
  },

  saveSettings: (settings: any) => {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  }
};
