import React, { useState } from 'react';
import { Project, ClinicalDocument, DocumentType, CustomTemplate, DocNode, ActivityLogItem } from '../types';
import { TEMPLATES } from '../constants';
import { 
  ChevronLeft, Plus, Trash2, Layers, Users, Settings, FileText, 
  CheckCircle2, Clock, AlertCircle, Calendar, User, Flag, 
  LayoutDashboard, Kanban, Database, Activity, Search, Filter
} from 'lucide-react';
import { StorageService } from '../services/storage';

interface Props {
  project: Project;
  customTemplates: CustomTemplate[];
  onBack: () => void;
  onOpenDocument: (doc: ClinicalDocument) => void;
  onUpdateProject: (p: Project) => void;
}

// --- Helpers ---
const calculateProgress = (doc: ClinicalDocument): number => {
  let total = 0;
  let filled = 0;
  const traverse = (nodes: DocNode[]) => {
    nodes.forEach(n => {
      if (!n.children || n.children.length === 0) {
         total++;
         if (doc.docData[n.id] && doc.docData[n.id].replace(/<[^>]*>/g, '').trim().length > 10) filled++;
      } else { traverse(n.children); }
    });
  };
  traverse(doc.docTree);
  return total === 0 ? 0 : Math.round((filled / total) * 100);
};

// --- Sub-Components ---

const DocCard: React.FC<{ doc: ClinicalDocument; onOpen: (d: ClinicalDocument) => void; onDelete: (id: string) => void }> = ({ doc, onOpen, onDelete }) => {
  const template = TEMPLATES[doc.type];
  const progress = calculateProgress(doc);
  
  // Priority Colors
  const priorityColor = doc.priority === 'high' ? 'text-red-600 bg-red-50 border-red-100' : doc.priority === 'medium' ? 'text-orange-600 bg-orange-50 border-orange-100' : 'text-slate-500 bg-slate-100 border-slate-200';

  return (
    <div 
      onClick={() => onOpen(doc)}
      className="bg-white rounded-xl border border-slate-200 shadow-sm hover:shadow-lg transition-all cursor-pointer group relative overflow-hidden flex flex-col h-48 animate-in fade-in"
    >
      <div className={`h-1.5 w-full ${template.color}`}></div>
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div className="flex justify-between items-start mb-2">
           <div className={`p-1.5 rounded-lg bg-opacity-10 ${template.color.replace('bg-', 'text-').replace('600', '600')} ${template.color.replace('bg-', 'bg-').replace('600', '50')}`}>
             <FileText className="w-4 h-4" />
           </div>
           {doc.priority && (
             <span className={`text-[9px] uppercase font-bold px-2 py-0.5 rounded-full border ${priorityColor} flex items-center gap-1`}>
               <Flag className="w-3 h-3" /> {doc.priority}
             </span>
           )}
        </div>

        <div>
           <h4 className="font-bold text-slate-800 text-sm leading-tight line-clamp-2 mb-1" title={doc.title}>{doc.title}</h4>
           <div className="flex items-center gap-2 text-[10px] text-slate-400">
             {doc.assignee && <span className="flex items-center gap-1"><User className="w-3 h-3"/> {doc.assignee}</span>}
             {doc.dueDate && <span className={`flex items-center gap-1 ${doc.dueDate < Date.now() ? 'text-red-500 font-bold' : ''}`}><Calendar className="w-3 h-3"/> {new Date(doc.dueDate).toLocaleDateString()}</span>}
           </div>
        </div>

        <div className="mt-2">
           <div className="flex justify-between text-[10px] text-slate-500 mb-1 font-medium">
             <span>{doc.status.toUpperCase()}</span>
             <span>{progress}%</span>
           </div>
           <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
              <div 
                className={`h-full rounded-full transition-all duration-1000 ${progress === 100 ? 'bg-emerald-500' : progress > 50 ? 'bg-blue-500' : 'bg-slate-300'}`} 
                style={{ width: `${progress}%` }}
              ></div>
           </div>
        </div>
        
        <button onClick={(e) => { e.stopPropagation(); onDelete(doc.id); }} className="absolute top-2 right-2 p-1.5 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded transition-all opacity-0 group-hover:opacity-100 transform scale-90 group-hover:scale-100">
          <Trash2 className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};

const AddDocButton: React.FC<{ types: DocumentType[], customTemplates: CustomTemplate[], onAdd: (t: DocumentType, c?: string) => void }> = ({ types, customTemplates, onAdd }) => {
  const relevantCustom = customTemplates.filter(t => types.includes(t.baseType));
  return (
    <div className="group relative h-48">
      <div className="absolute inset-0 bg-slate-50 border-2 border-dashed border-slate-200 rounded-xl flex flex-col items-center justify-center text-slate-400 transition-colors group-hover:border-blue-400 group-hover:bg-blue-50/30 hover:shadow-inner">
        <Plus className="w-8 h-8 mb-2 opacity-50 group-hover:opacity-100 transition-opacity text-blue-500" />
        <span className="text-xs font-bold text-slate-500 group-hover:text-blue-600">Create Document</span>
      </div>
      <div className="absolute inset-x-0 bottom-0 top-auto bg-white rounded-xl flex flex-col p-2 gap-1 overflow-y-auto opacity-0 group-hover:opacity-100 invisible group-hover:visible transition-all z-20 border border-slate-200 shadow-xl custom-scrollbar max-h-64 transform translate-y-2 group-hover:translate-y-0">
        <span className="text-[9px] font-bold text-slate-400 uppercase text-center mb-1 tracking-wider">Standard</span>
        {types.map(t => (
          <button key={t} onClick={() => onAdd(t)} className="text-xs py-2 px-3 bg-slate-50 hover:bg-blue-50 hover:text-blue-600 rounded-lg text-left truncate font-medium transition-colors flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${TEMPLATES[t].color}`}></div>{TEMPLATES[t].title}
          </button>
        ))}
        {relevantCustom.length > 0 && (
          <>
            <div className="h-px bg-slate-100 my-1"></div>
            <span className="text-[9px] font-bold text-slate-400 uppercase text-center mb-1 tracking-wider">Custom</span>
            {relevantCustom.map(t => (
               <button key={t.id} onClick={() => onAdd(t.baseType, t.id)} className="text-xs py-2 px-3 bg-purple-50 hover:bg-purple-100 hover:text-purple-700 text-purple-600 rounded-lg text-left truncate font-medium transition-colors border border-purple-100">{t.name}</button>
            ))}
          </>
        )}
      </div>
    </div>
  );
};

const KanbanColumn: React.FC<{ title: string; status: string; docs: ClinicalDocument[]; onOpen: (d: ClinicalDocument) => void }> = ({ title, status, docs, onOpen }) => (
    <div className="flex-1 min-w-[300px] flex flex-col bg-slate-100 rounded-xl p-3 h-full">
        <div className="flex justify-between items-center mb-3 px-1">
            <span className="font-bold text-slate-600 text-sm">{title}</span>
            <span className="bg-slate-200 text-slate-600 text-[10px] font-bold px-2 py-0.5 rounded-full">{docs.length}</span>
        </div>
        <div className="flex-1 overflow-y-auto space-y-3 custom-scrollbar pr-1">
            {docs.map(doc => (
                <div key={doc.id} onClick={() => onOpen(doc)} className="bg-white p-3 rounded-lg shadow-sm hover:shadow-md cursor-pointer border border-slate-200 transition-all">
                    <div className="flex justify-between items-start mb-2">
                        <span className={`text-[9px] px-1.5 py-0.5 rounded font-bold uppercase ${TEMPLATES[doc.type].color.replace('bg-','text-').replace('600','600')} bg-slate-50`}>{TEMPLATES[doc.type].icon} {doc.type}</span>
                        {doc.priority === 'high' && <Flag className="w-3 h-3 text-red-500 fill-red-500" />}
                    </div>
                    <div className="font-bold text-slate-800 text-sm mb-2">{doc.title}</div>
                    <div className="flex justify-between items-center text-[10px] text-slate-400">
                        <span>{doc.assignee || 'Unassigned'}</span>
                        {doc.dueDate && <span className={doc.dueDate < Date.now() ? "text-red-500 font-bold" : ""}>{new Date(doc.dueDate).toLocaleDateString()}</span>}
                    </div>
                </div>
            ))}
            {docs.length === 0 && <div className="text-center py-10 text-slate-400 text-xs italic opacity-50">No documents</div>}
        </div>
    </div>
);

// --- MAIN COMPONENT ---

const ProjectHub: React.FC<Props> = ({ project, customTemplates, onBack, onOpenDocument, onUpdateProject }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'documents' | 'kanban' | 'data'>('overview');
  const [isEditingName, setIsEditingName] = useState(false);
  const [tempName, setTempName] = useState(project.projectName);
  
  // Handlers
  const handleRenameProject = async () => {
    if (!tempName.trim()) {
        setTempName(project.projectName);
        setIsEditingName(false);
        return;
    }
    const updated = { ...project, projectName: tempName, updatedAt: Date.now() };
    await StorageService.saveProject(updated);
    onUpdateProject(updated);
    setIsEditingName(false);
  };

  const addLog = (action: string, target: string) => {
      const log: ActivityLogItem = { id: Math.random().toString(), action, target, user: "Me", timestamp: Date.now() };
      return [...(project.activityLog || []), log];
  };

  const extractDefaultData = (nodes: DocNode[]) => {
    let data: Record<string, string> = {};
    const traverse = (n: DocNode[]) => {
      n.forEach(node => { if (node.defaultContent) data[node.id] = node.defaultContent; if (node.children) traverse(node.children); });
    };
    traverse(nodes);
    return data;
  };

  const handleCreateDocument = async (type: DocumentType, customTemplateId?: string) => {
    let structure = TEMPLATES[type].structure;
    let title = TEMPLATES[type].title;
    if (customTemplateId) {
        const custom = customTemplates.find(c => c.id === customTemplateId);
        if (custom) { structure = custom.structure; title = custom.name; }
    }
    const newDoc: ClinicalDocument = {
      id: Math.random().toString(36).substr(2, 9), title, type, status: 'draft',
      docTree: JSON.parse(JSON.stringify(structure)), docData: extractDefaultData(structure),
      versions: [], updatedAt: Date.now(), assignee: 'Unassigned', priority: 'medium'
    };
    const updated = { ...project, documents: [...project.documents, newDoc], activityLog: addLog("Created Document", title), updatedAt: Date.now() };
    await StorageService.saveProject(updated);
    onUpdateProject(updated);
  };

  const handleDeleteDocument = async (docId: string) => {
    if (!confirm("Delete this document?")) return;
    const docTitle = project.documents.find(d => d.id === docId)?.title || "Unknown Doc";
    const updated = { ...project, documents: project.documents.filter(d => d.id !== docId), activityLog: addLog("Deleted Document", docTitle), updatedAt: Date.now() };
    await StorageService.saveProject(updated);
    onUpdateProject(updated);
  };

  const handleUpdateVariables = async (key: string, value: string) => {
      const updated = { ...project, variables: { ...project.variables, [key]: value }, updatedAt: Date.now() };
      await StorageService.saveProject(updated);
      onUpdateProject(updated);
  };

  const getBinderDocs = (category: 'trial' | 'subject' | 'operation') => {
    const trialTypes = ['protocol', 'ib', 'worksheet'];
    const subjectTypes = ['icf', 'diary', 'participation_card', 'ad'];
    const opTypes = ['sap', 'dmp', 'cmp', 'manual', 'csr'];
    const target = category === 'trial' ? trialTypes : category === 'subject' ? subjectTypes : opTypes;
    return project.documents.filter(d => target.includes(d.type));
  };

  // Stats
  const stats = {
      total: project.documents.length,
      final: project.documents.filter(d => d.status === 'final').length,
      draft: project.documents.filter(d => d.status === 'draft').length,
      overdue: project.documents.filter(d => d.dueDate && d.dueDate < Date.now() && d.status !== 'final').length
  };

  return (
    <div className="min-h-screen bg-[#F0F2F5] flex flex-col font-sans">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 px-6 h-16 flex items-center justify-between shadow-sm sticky top-0 z-30">
        <div className="flex items-center gap-4">
           <button onClick={onBack} className="p-2 hover:bg-slate-100 rounded-full text-slate-500 transition-colors">
             <ChevronLeft className="w-5 h-5" />
           </button>
           <div className="flex flex-col">
              {isEditingName ? (
                  <input 
                    autoFocus
                    className="text-xl font-bold text-slate-900 border-b-2 border-blue-500 outline-none bg-transparent"
                    value={tempName}
                    onChange={(e) => setTempName(e.target.value)}
                    onBlur={handleRenameProject}
                    onKeyDown={(e) => e.key === 'Enter' && handleRenameProject()}
                  />
              ) : (
                  <h1 
                    className="text-xl font-bold text-slate-900 cursor-pointer hover:text-blue-600 transition-colors flex items-center gap-2 group"
                    onClick={() => { setTempName(project.projectName); setIsEditingName(true); }}
                    title="Click to rename project"
                  >
                    {project.projectName}
                    <Settings className="w-3.5 h-3.5 opacity-0 group-hover:opacity-50" />
                  </h1>
              )}
              <p className="text-xs text-slate-500 flex items-center gap-2">
                 <Clock className="w-3 h-3" /> Last updated {new Date(project.updatedAt).toLocaleDateString()}
              </p>
           </div>
        </div>
        
        {/* Navigation Tabs */}
        <div className="flex bg-slate-100 p-1 rounded-lg">
            <button onClick={() => setActiveTab('overview')} className={`px-4 py-1.5 rounded-md text-sm font-medium transition-all flex items-center gap-2 ${activeTab === 'overview' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>
                <LayoutDashboard className="w-4 h-4" /> Overview
            </button>
            <button onClick={() => setActiveTab('documents')} className={`px-4 py-1.5 rounded-md text-sm font-medium transition-all flex items-center gap-2 ${activeTab === 'documents' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>
                <Layers className="w-4 h-4" /> Binders
            </button>
            <button onClick={() => setActiveTab('kanban')} className={`px-4 py-1.5 rounded-md text-sm font-medium transition-all flex items-center gap-2 ${activeTab === 'kanban' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>
                <Kanban className="w-4 h-4" /> Kanban
            </button>
            <button onClick={() => setActiveTab('data')} className={`px-4 py-1.5 rounded-md text-sm font-medium transition-all flex items-center gap-2 ${activeTab === 'data' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>
                <Database className="w-4 h-4" /> Study Data
            </button>
        </div>
      </header>

      <div className="flex-1 p-8 max-w-[1600px] mx-auto w-full overflow-hidden flex flex-col">
        
        {/* OVERVIEW TAB */}
        {activeTab === 'overview' && (
            <div className="grid grid-cols-12 gap-8 animate-in fade-in slide-in-from-bottom-2">
                {/* Stats Cards */}
                <div className="col-span-12 grid grid-cols-4 gap-4">
                    <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
                        <div className="text-slate-500 text-xs font-bold uppercase tracking-wider mb-2">Completion</div>
                        <div className="text-3xl font-bold text-slate-800">{Math.round((stats.final / (stats.total || 1)) * 100)}%</div>
                        <div className="h-1.5 w-full bg-slate-100 rounded-full mt-2 overflow-hidden"><div className="h-full bg-blue-500" style={{width: `${Math.round((stats.final / (stats.total || 1)) * 100)}%`}}></div></div>
                    </div>
                    <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
                        <div className="text-slate-500 text-xs font-bold uppercase tracking-wider mb-2">Documents</div>
                        <div className="flex items-end gap-2">
                            <span className="text-3xl font-bold text-slate-800">{stats.total}</span>
                            <span className="text-sm text-slate-400 mb-1">Files in TMF</span>
                        </div>
                    </div>
                    <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
                        <div className="text-slate-500 text-xs font-bold uppercase tracking-wider mb-2">At Risk</div>
                        <div className="flex items-end gap-2">
                            <span className="text-3xl font-bold text-red-600">{stats.overdue}</span>
                            <span className="text-sm text-slate-400 mb-1">Overdue items</span>
                        </div>
                    </div>
                    <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-center items-start">
                         <div className="text-slate-500 text-xs font-bold uppercase tracking-wider mb-2">Next Milestone</div>
                         <div className="font-bold text-slate-800">Protocol Finalization</div>
                         <div className="text-xs text-blue-600 font-medium">Due in 5 days</div>
                    </div>
                </div>

                {/* Activity Feed */}
                <div className="col-span-8 bg-white rounded-xl border border-slate-200 shadow-sm p-6">
                    <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2"><Activity className="w-5 h-5 text-blue-600" /> Recent Activity</h3>
                    <div className="space-y-4">
                        {(project.activityLog || []).length === 0 && <p className="text-slate-400 italic">No activity recorded yet.</p>}
                        {[...(project.activityLog || [])].reverse().slice(0, 5).map(log => (
                            <div key={log.id} className="flex gap-4 items-start pb-4 border-b border-slate-100 last:border-0">
                                <div className="w-8 h-8 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center font-bold text-xs">{log.user.charAt(0)}</div>
                                <div>
                                    <p className="text-sm text-slate-800"><span className="font-bold">{log.user}</span> {log.action} <span className="font-medium text-blue-600">{log.target}</span></p>
                                    <p className="text-xs text-slate-400">{new Date(log.timestamp).toLocaleString()}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Quick Actions */}
                <div className="col-span-4 space-y-4">
                    <div className="bg-gradient-to-br from-indigo-600 to-purple-700 rounded-xl p-6 text-white shadow-lg">
                        <h3 className="font-bold text-lg mb-2">Manager Actions</h3>
                        <p className="text-indigo-100 text-sm mb-4">Quickly access key management functions.</p>
                        <div className="space-y-2">
                            <button onClick={() => setActiveTab('kanban')} className="w-full py-2 bg-white/10 hover:bg-white/20 rounded-lg text-sm font-medium text-left px-4 transition-colors">View Workflow Board</button>
                            <button onClick={() => setActiveTab('data')} className="w-full py-2 bg-white/10 hover:bg-white/20 rounded-lg text-sm font-medium text-left px-4 transition-colors">Edit Study Variables</button>
                        </div>
                    </div>
                </div>
            </div>
        )}

        {/* DOCUMENTS TAB (Binders) */}
        {activeTab === 'documents' && (
            <div className="space-y-10 animate-in fade-in slide-in-from-bottom-2">
                 <section>
                    <div className="flex items-center gap-3 mb-4 pb-2 border-b border-slate-200">
                        <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center"><Layers className="w-4 h-4" /></div>
                        <div><h2 className="text-lg font-bold text-slate-800">Trial Binder</h2></div>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
                        {getBinderDocs('trial').map(doc => <DocCard key={doc.id} doc={doc} onOpen={onOpenDocument} onDelete={handleDeleteDocument} />)}
                        <AddDocButton types={['protocol', 'ib', 'worksheet']} customTemplates={customTemplates} onAdd={handleCreateDocument} />
                    </div>
                </section>
                <section>
                    <div className="flex items-center gap-3 mb-4 pb-2 border-b border-slate-200">
                        <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-600 flex items-center justify-center"><Users className="w-4 h-4" /></div>
                        <div><h2 className="text-lg font-bold text-slate-800">Subject Binder</h2></div>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
                        {getBinderDocs('subject').map(doc => <DocCard key={doc.id} doc={doc} onOpen={onOpenDocument} onDelete={handleDeleteDocument} />)}
                        <AddDocButton types={['icf', 'diary', 'participation_card', 'ad']} customTemplates={customTemplates} onAdd={handleCreateDocument} />
                    </div>
                </section>
                <section>
                    <div className="flex items-center gap-3 mb-4 pb-2 border-b border-slate-200">
                        <div className="w-8 h-8 rounded-lg bg-slate-200 text-slate-600 flex items-center justify-center"><Settings className="w-4 h-4" /></div>
                        <div><h2 className="text-lg font-bold text-slate-800">Operation Binder</h2></div>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
                        {getBinderDocs('operation').map(doc => <DocCard key={doc.id} doc={doc} onOpen={onOpenDocument} onDelete={handleDeleteDocument} />)}
                        <AddDocButton types={['sap', 'dmp', 'cmp', 'manual', 'csr']} customTemplates={customTemplates} onAdd={handleCreateDocument} />
                    </div>
                </section>
            </div>
        )}

        {/* KANBAN TAB */}
        {activeTab === 'kanban' && (
             <div className="flex-1 flex gap-4 overflow-x-auto pb-4 animate-in fade-in slide-in-from-bottom-2 h-full">
                 <KanbanColumn title="Drafting" status="draft" docs={project.documents.filter(d => d.status === 'draft')} onOpen={onOpenDocument} />
                 <KanbanColumn title="Internal Review" status="review" docs={project.documents.filter(d => d.status === 'review')} onOpen={onOpenDocument} />
                 <KanbanColumn title="QC / Audit" status="qc" docs={project.documents.filter(d => d.status === 'qc')} onOpen={onOpenDocument} />
                 <KanbanColumn title="Final / Approved" status="final" docs={project.documents.filter(d => d.status === 'final')} onOpen={onOpenDocument} />
             </div>
        )}

        {/* DATA TAB */}
        {activeTab === 'data' && (
            <div className="grid grid-cols-12 gap-8 animate-in fade-in slide-in-from-bottom-2 h-full">
                <div className="col-span-4">
                     <div className="bg-blue-50 border border-blue-100 p-6 rounded-xl mb-6">
                        <h3 className="font-bold text-blue-800 text-lg mb-2">Single Source of Truth</h3>
                        <p className="text-blue-600 text-sm">
                            These variables power the AI generation across all documents. 
                            Updating a value here ensures consistency when you regenerate content in any document.
                        </p>
                     </div>
                     <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                        <h4 className="font-bold text-slate-800 mb-4">Export Data</h4>
                        <button className="w-full py-2 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-700 font-medium text-sm transition-colors mb-2">Download Variables (JSON)</button>
                        <button className="w-full py-2 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-700 font-medium text-sm transition-colors">Print Summary</button>
                     </div>
                </div>
                <div className="col-span-8 bg-white rounded-xl border border-slate-200 shadow-sm flex flex-col h-full overflow-hidden">
                     <div className="p-4 border-b bg-slate-50 flex justify-between items-center">
                         <h3 className="font-bold text-slate-700">Study Variables Editor</h3>
                         <div className="relative">
                             <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"/>
                             <input placeholder="Search variables..." className="pl-9 pr-4 py-1.5 rounded-full border text-sm outline-none focus:ring-2 focus:ring-blue-500"/>
                         </div>
                     </div>
                     <div className="flex-1 overflow-y-auto p-6 space-y-6">
                         {Object.entries(project.variables).map(([key, value]) => (
                             <div key={key} className="grid grid-cols-12 gap-4 items-start">
                                 <div className="col-span-4">
                                     <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block pt-2">{key.replace(/([A-Z])/g, ' $1').trim()}</label>
                                 </div>
                                 <div className="col-span-8">
                                     <textarea 
                                        value={value} 
                                        onChange={(e) => handleUpdateVariables(key, e.target.value)}
                                        className="w-full p-3 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none transition-all min-h-[44px]"
                                        rows={Math.max(2, Math.min(10, (value as string).split('\n').length))}
                                     />
                                 </div>
                             </div>
                         ))}
                     </div>
                </div>
            </div>
        )}

      </div>
    </div>
  );
};

export default ProjectHub;