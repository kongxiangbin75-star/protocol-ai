import React, { useState } from 'react';
import { ApiConfig, ClinicalVariables, CustomTemplate } from '../types';
import { TEMPLATES, INITIAL_VARIABLES } from '../constants';
import { parseFile } from '../services/parser';
import { extractVariablesFromText } from '../services/gemini';
import { ChevronRight, Upload, Sparkles, FileText, CheckCircle2, Trash2, Plus, LayoutTemplate } from 'lucide-react';

interface Props {
  onComplete: (data: any) => void;
  onCancel: () => void;
  apiConfig: ApiConfig;
  customTemplates: CustomTemplate[];
}

interface UploadedFile {
  id: string;
  name: string;
  content: string;
}

const ProjectWizard: React.FC<Props> = ({ onComplete, onCancel, apiConfig, customTemplates }) => {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [projectName, setProjectName] = useState('New Clinical Trial');
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>(''); // Empty means default
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [variables, setVariables] = useState<ClinicalVariables>(INITIAL_VARIABLES);

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setLoading(true);
    try {
      const text = await parseFile(file);
      setUploadedFiles(prev => [...prev, { id: Math.random().toString(36).substr(2, 9), name: file.name, content: text }]);
    } catch (err) { alert("Error reading file: " + (err as Error).message); } finally { setLoading(false); e.target.value = ''; }
  };

  const removeFile = (id: string) => setUploadedFiles(prev => prev.filter(f => f.id !== id));

  const runExtraction = async () => {
    if (uploadedFiles.length === 0) return alert("Please upload at least one document.");
    setLoading(true);
    try {
      const fullText = uploadedFiles.map(f => `--- ${f.name} ---\n${f.content}`).join('\n\n');
      const extracted = await extractVariablesFromText(apiConfig, fullText);
      setVariables(prev => ({ ...prev, ...extracted }));
      if (extracted.trialId && extracted.trialId !== "Not specified") setProjectName(extracted.trialId);
      setStep(3);
    } catch (err) { alert("AI Extraction failed: " + (err as Error).message); } finally { setLoading(false); }
  };

  // Filter for Protocol templates
  const protocolTemplates = customTemplates.filter(t => t.baseType === 'protocol');

  return (
    <div className="fixed inset-0 bg-[#F5F5F7] z-50 flex flex-col animate-in fade-in duration-300">
      <div className="h-16 bg-white border-b flex items-center justify-between px-8 shadow-sm">
        <h2 className="font-bold text-xl text-slate-800">New Clinical Project</h2>
        <button onClick={onCancel} className="text-slate-500 hover:text-slate-800 text-sm font-medium">Cancel</button>
      </div>

      <div className="flex-1 overflow-y-auto p-8">
        <div className="max-w-4xl mx-auto grid grid-cols-12 gap-8">
          <div className="col-span-3 space-y-2">
            {[1, 2, 3].map(s => (
              <div key={s} onClick={() => setStep(s)} className={`p-4 rounded-xl border transition-all cursor-pointer hover:bg-slate-50 ${step === s ? 'bg-white border-blue-200 shadow-md ring-1 ring-blue-200' : 'border-transparent opacity-60'}`}>
                <span className={`text-xs font-bold uppercase tracking-wider block mb-1 ${step === s ? 'text-blue-600' : 'text-slate-400'}`}>Step {s}</span>
                <span className={`font-bold ${step === s ? 'text-blue-900' : 'text-slate-700'}`}>{s === 1 ? "Basics" : s === 2 ? "Source Material" : "Review"}</span>
              </div>
            ))}
          </div>

          <div className="col-span-9 space-y-6">
            {step === 1 && (
              <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200 animate-in slide-in-from-right-4">
                <h3 className="text-lg font-bold mb-6">Trial Details</h3>
                
                <div className="mb-6">
                    <label className="block text-sm font-medium text-slate-700 mb-1">Trial Name / ID</label>
                    <input value={projectName} onChange={e => setProjectName(e.target.value)} className="w-full p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none transition-all" />
                </div>

                <div>
                   <label className="block text-sm font-medium text-slate-700 mb-2">Initial Protocol Template</label>
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {/* Default Card */}
                      <div 
                        onClick={() => setSelectedTemplateId('')}
                        className={`p-4 rounded-xl border cursor-pointer transition-all flex items-start gap-3 ${selectedTemplateId === '' ? 'bg-blue-50 border-blue-400 ring-1 ring-blue-400' : 'bg-white border-slate-200 hover:border-blue-200'}`}
                      >
                         <div className="p-2 bg-blue-100 rounded-lg text-blue-600"><FileText className="w-5 h-5" /></div>
                         <div>
                            <div className="font-bold text-slate-700 text-sm">Standard Protocol</div>
                            <div className="text-xs text-slate-500">Default ICH-GCP structure</div>
                         </div>
                      </div>

                      {/* Custom Templates */}
                      {protocolTemplates.map(t => (
                        <div 
                          key={t.id}
                          onClick={() => setSelectedTemplateId(t.id)}
                          className={`p-4 rounded-xl border cursor-pointer transition-all flex items-start gap-3 ${selectedTemplateId === t.id ? 'bg-purple-50 border-purple-400 ring-1 ring-purple-400' : 'bg-white border-slate-200 hover:border-purple-200'}`}
                        >
                           <div className="p-2 bg-purple-100 rounded-lg text-purple-600"><LayoutTemplate className="w-5 h-5" /></div>
                           <div>
                              <div className="font-bold text-slate-700 text-sm">{t.name}</div>
                              <div className="text-xs text-slate-500">Custom Template</div>
                           </div>
                        </div>
                      ))}
                   </div>
                </div>

                <div className="mt-8 flex justify-end">
                  <button onClick={() => setStep(2)} className="px-6 py-2 bg-blue-600 text-white rounded-lg font-medium flex items-center gap-2 hover:bg-blue-700 transition-colors">Next <ChevronRight className="w-4 h-4" /></button>
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200 animate-in slide-in-from-right-4">
                <h3 className="text-lg font-bold mb-2">Upload Source Material</h3>
                <p className="text-slate-500 text-sm mb-6">Upload synopses, previous protocols, etc. to extract study variables.</p>
                <div className="space-y-3 mb-6">
                  {uploadedFiles.map(file => (
                    <div key={file.id} className="flex items-center justify-between p-3 bg-slate-50 border rounded-lg animate-in fade-in">
                      <div className="flex items-center gap-3"><FileText className="w-5 h-5 text-blue-500" /><p className="text-sm font-medium text-slate-700">{file.name}</p></div>
                      <button onClick={() => removeFile(file.id)} className="p-2 text-slate-400 hover:text-red-500 rounded-full hover:bg-red-50"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  ))}
                  <div className="relative">
                    <input type="file" id="file-upload" onChange={handleFile} className="hidden" accept=".pdf,.docx" disabled={loading} />
                    <label htmlFor="file-upload" className={`w-full border-2 border-dashed rounded-xl p-4 flex items-center justify-center gap-2 cursor-pointer transition-colors ${loading ? 'bg-slate-50 opacity-50 cursor-wait' : 'border-slate-300 hover:border-blue-400 hover:bg-blue-50'}`}>
                      {loading ? <Sparkles className="w-5 h-5 animate-pulse text-blue-500" /> : <Plus className="w-5 h-5 text-slate-400" />}
                      <span className="text-sm font-medium text-slate-600">{loading ? 'Reading...' : 'Add Document'}</span>
                    </label>
                  </div>
                </div>
                <div className="mt-8 flex justify-between">
                  <button onClick={() => setStep(1)} className="text-slate-500 hover:text-slate-800">Back</button>
                  <div className="flex gap-3">
                    <button onClick={() => setStep(3)} className="px-4 py-2 text-slate-600 font-medium hover:bg-slate-100 rounded-lg">Skip Extraction</button>
                    <button onClick={runExtraction} disabled={uploadedFiles.length === 0 || loading} className="px-6 py-2 bg-indigo-600 text-white rounded-lg font-medium flex items-center gap-2 hover:bg-indigo-700 disabled:opacity-50 transition-all">{loading ? 'Analyzing...' : <><Sparkles className="w-4 h-4" /> Extract</>}</button>
                  </div>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200 animate-in slide-in-from-right-4 flex flex-col h-[600px]">
                <div className="flex justify-between items-center mb-4"><h3 className="text-lg font-bold">Review Parameters</h3></div>
                <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar">
                  <div className="space-y-4">
                    {Object.entries(variables).map(([k, v]) => (
                      <div key={k}><label className="block text-xs font-bold text-slate-400 uppercase mb-1 tracking-wider">{k.replace(/([A-Z])/g, ' $1').trim()}</label><textarea value={v} onChange={e => setVariables({ ...variables, [k]: e.target.value })} className="w-full p-3 border border-slate-200 rounded-lg text-sm bg-slate-50 focus:bg-white focus:ring-1 focus:ring-blue-500 outline-none transition-colors min-h-[80px]" /></div>
                    ))}
                  </div>
                </div>
                <div className="mt-6 pt-4 border-t flex justify-between">
                  <button onClick={() => setStep(2)} className="text-slate-500 hover:text-slate-800">Back</button>
                  <button onClick={() => onComplete({ projectName, variables, selectedTemplateId })} className="px-8 py-3 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 shadow-lg transition-all flex items-center gap-2">Create Project <ChevronRight className="w-4 h-4" /></button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
export default ProjectWizard;