
import React, { useState, useEffect } from 'react';
import { CustomTemplate, DocumentType, DocNode, ApiConfig } from '../types';
import { StorageService } from '../services/storage';
import { parseFile } from '../services/parser';
import { extractTemplateStructure } from '../services/gemini';
import { TEMPLATES } from '../constants';
import { 
  ChevronLeft, Upload, Loader2, Save, FileText, Trash2, Plus, 
  Sparkles, Edit2, Copy, Download, Import, MoreVertical, LayoutTemplate 
} from 'lucide-react';

interface Props {
  onBack: () => void;
  apiConfig: ApiConfig;
}

const TemplateManager: React.FC<Props> = ({ onBack, apiConfig }) => {
  const [templates, setTemplates] = useState<CustomTemplate[]>([]);
  const [view, setView] = useState<'list' | 'create'>('list');
  const [name, setName] = useState('');
  const [baseType, setBaseType] = useState<DocumentType>('protocol');
  const [file, setFile] = useState<File | null>(null);
  const [processing, setProcessing] = useState(false);
  const [structure, setStructure] = useState<DocNode[] | null>(null);

  useEffect(() => { loadTemplates(); }, []);

  const loadTemplates = async () => {
    const data = await StorageService.getCustomTemplates();
    setTemplates(data);
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Delete this template?")) return;
    await StorageService.deleteCustomTemplate(id);
    loadTemplates();
  };

  const handleClone = async (template: CustomTemplate) => {
    const cloned: CustomTemplate = {
      ...template,
      id: Math.random().toString(36).substr(2, 9),
      name: `${template.name} (Copy)`,
      createdAt: Date.now()
    };
    await StorageService.saveCustomTemplate(cloned);
    loadTemplates();
  };

  const handleExport = (template: CustomTemplate) => {
    const blob = new Blob([JSON.stringify(template, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = window.document.createElement('a');
    a.href = url;
    a.download = `${template.name.replace(/\s+/g, '_')}_template.json`;
    a.click();
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (evt) => {
      try {
        const imported = JSON.parse(evt.target?.result as string) as CustomTemplate;
        imported.id = Math.random().toString(36).substr(2, 9);
        imported.createdAt = Date.now();
        await StorageService.saveCustomTemplate(imported);
        loadTemplates();
      } catch (err) { alert("Invalid template file."); }
    };
    reader.readAsText(file);
  };

  const handleProcess = async () => {
    if (!file || !name) return alert("Missing name or file.");
    setProcessing(true);
    try {
      const text = await parseFile(file);
      const res = await extractTemplateStructure(apiConfig, text);
      setStructure(res);
    } catch (e) { alert("Error: " + (e as Error).message); }
    finally { setProcessing(false); }
  };

  const handleSave = async () => {
    if (!structure) return;
    const t: CustomTemplate = { id: Math.random().toString(36).substr(2, 9), name, baseType, structure, createdAt: Date.now() };
    await StorageService.saveCustomTemplate(t);
    setView('list');
    loadTemplates();
    setStructure(null); setName(''); setFile(null);
  };

  const renderTree = (nodes: DocNode[], depth = 0) => (
    <div className="space-y-1">
      {nodes.map(node => (
        <div key={node.id}>
          <div className="text-sm py-1 px-2 rounded hover:bg-slate-50 flex items-center justify-between group" style={{ marginLeft: depth * 16 }}>
            <span className="text-slate-700 truncate">{node.title}</span>
            <div className="flex opacity-0 group-hover:opacity-100 gap-1">
              <button onClick={() => {
                const n = prompt("New name:", node.title);
                if (n) {
                  const update = (items: DocNode[]): DocNode[] => items.map(i => i.id === node.id ? { ...i, title: n } : { ...i, children: i.children ? update(i.children) : undefined });
                  setStructure(update(structure!));
                }
              }} className="p-1 hover:text-blue-600"><Edit2 className="w-3 h-3" /></button>
            </div>
          </div>
          {node.children && renderTree(node.children, depth + 1)}
        </div>
      ))}
    </div>
  );

  return (
    <div className="flex flex-col h-screen bg-[#F8FAFC]">
      <header className="h-16 bg-white border-b flex items-center justify-between px-6 shadow-sm z-10">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 hover:bg-slate-100 rounded-full transition-colors"><ChevronLeft className="w-5 h-5 text-slate-600" /></button>
          <h2 className="text-xl font-bold text-slate-800">Template Manager</h2>
        </div>
        <div className="flex gap-2">
          <label className="px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-sm font-medium hover:bg-slate-50 cursor-pointer flex items-center gap-2">
            <Import className="w-4 h-4" /> Import <input type="file" className="hidden" accept=".json" onChange={handleImport} />
          </label>
          <button onClick={() => setView('create')} className="px-4 py-1.5 bg-blue-600 text-white rounded-lg text-sm font-bold hover:bg-blue-700 flex items-center gap-2 shadow-sm"><Plus className="w-4 h-4" /> Create New</button>
        </div>
      </header>

      <div className="flex-1 overflow-hidden p-6 max-w-6xl mx-auto w-full">
        {view === 'list' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {templates.map(t => (
              <div key={t.id} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-lg transition-all group flex flex-col">
                <div className="flex justify-between items-start mb-4">
                  <div className={`p-3 rounded-xl ${TEMPLATES[t.baseType]?.color || 'bg-slate-500'} bg-opacity-10 text-slate-700`}><FileText className="w-6 h-6" /></div>
                  <div className="flex gap-1">
                    <button onClick={() => handleClone(t)} className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg"><Copy className="w-4 h-4" /></button>
                    <button onClick={() => handleExport(t)} className="p-2 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg"><Download className="w-4 h-4" /></button>
                    <button onClick={() => handleDelete(t.id)} className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg"><Trash2 className="w-4 h-4" /></button>
                  </div>
                </div>
                <h3 className="font-bold text-slate-800 text-lg mb-1">{t.name}</h3>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-4">{TEMPLATES[t.baseType]?.title || t.baseType}</span>
                <div className="mt-auto pt-4 border-t flex justify-between items-center text-xs text-slate-400">
                  <span>{t.structure.length} Main Sections</span>
                  <span>{new Date(t.createdAt).toLocaleDateString()}</span>
                </div>
              </div>
            ))}
            {templates.length === 0 && <div className="col-span-full py-20 text-center text-slate-400 bg-white rounded-2xl border border-dashed"><Sparkles className="w-12 h-12 mx-auto mb-2 opacity-20" /><p>No templates yet. Create your first one!</p></div>}
          </div>
        ) : (
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 h-full flex flex-col overflow-hidden animate-in slide-in-from-right-4">
            <div className="flex-1 flex min-h-0">
              <div className="w-1/3 border-r p-8 flex flex-col gap-6 bg-slate-50/50">
                <div><label className="block text-sm font-bold text-slate-700 mb-2">Template Name</label><input value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Standard Protocol v3" className="w-full p-3 bg-white border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500" /></div>
                <div><label className="block text-sm font-bold text-slate-700 mb-2">Base Category</label><select value={baseType} onChange={e => setBaseType(e.target.value as DocumentType)} className="w-full p-3 bg-white border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500">{Object.entries(TEMPLATES).map(([k,v]) => <option key={k} value={k}>{v.title}</option>)}</select></div>
                <div className="border-t pt-6">
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">Auto-Extract (Optional)</p>
                  <div className={`border-2 border-dashed rounded-xl p-6 text-center transition-colors ${file ? 'bg-blue-50 border-blue-400' : 'bg-white border-slate-200 hover:bg-slate-50'}`}>
                    <input type="file" id="template-up" className="hidden" accept=".pdf,.docx" onChange={e => setFile(e.target.files?.[0] || null)} />
                    <label htmlFor="template-up" className="cursor-pointer">
                      {file ? <div className="text-blue-600 font-bold flex flex-col items-center"><FileText className="w-8 h-8 mb-2" /> {file.name}</div> : <div className="text-slate-400"><Upload className="w-8 h-8 mx-auto mb-2" /> Upload reference doc</div>}
                    </label>
                  </div>
                  <button onClick={handleProcess} disabled={!file || !name || processing} className="w-full mt-4 py-3 bg-indigo-600 text-white rounded-xl font-bold flex items-center justify-center gap-2 disabled:opacity-50 shadow-md">
                    {processing ? <Loader2 className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />} {processing ? 'Analyzing...' : 'Extract via AI'}
                  </button>
                </div>
                <div className="mt-auto flex flex-col gap-2">
                  <button onClick={handleSave} disabled={!structure} className="w-full py-3 bg-emerald-600 text-white rounded-xl font-bold flex items-center justify-center gap-2 shadow-lg disabled:opacity-50"><Save className="w-5 h-5" /> Save Template</button>
                  <button onClick={() => { setView('list'); setStructure(null); }} className="w-full py-2 text-slate-500 font-medium">Cancel</button>
                </div>
              </div>
              <div className="flex-1 p-8 flex flex-col min-h-0 bg-white">
                <div className="flex justify-between items-center mb-6"><h3 className="font-bold text-slate-800 text-xl">Structure Preview</h3><button onClick={() => setStructure([])} className="text-xs font-bold text-slate-400 hover:text-red-500 uppercase">Reset Structure</button></div>
                <div className="flex-1 overflow-y-auto border border-slate-100 rounded-2xl p-6 custom-scrollbar">
                  {structure ? renderTree(structure) : <div className="h-full flex flex-col items-center justify-center text-slate-300 italic"><LayoutTemplate className="w-12 h-12 mb-2 opacity-10" /> Upload a file to extract or start adding root sections manually.</div>}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default TemplateManager;
