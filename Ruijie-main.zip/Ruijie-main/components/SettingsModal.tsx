
import React, { useState } from 'react';
import { ApiConfig } from '../types';
import { Settings, X, Info } from 'lucide-react';
import { AVAILABLE_MODELS, PROVIDER_DEFAULTS } from '../constants';

interface Props {
  config: ApiConfig;
  onSave: (cfg: ApiConfig) => void;
  onClose: () => void;
}

const SettingsModal: React.FC<Props> = ({ config, onSave, onClose }) => {
  const [provider, setProvider] = useState<ApiConfig['provider']>(config.provider || 'Gemini');
  const [model, setModel] = useState(config.model);
  const [apiKey, setApiKey] = useState(config.apiKey || '');
  const [baseUrl, setBaseUrl] = useState(config.baseUrl || '');

  const handleProviderChange = (newProvider: ApiConfig['provider']) => {
    setProvider(newProvider);
    const defaults = PROVIDER_DEFAULTS[newProvider];
    setBaseUrl(defaults.baseUrl);
    setModel(defaults.defaultModel);
  };

  const filteredModels = AVAILABLE_MODELS.filter(m => m.provider === provider);
  const selectedModelInfo = AVAILABLE_MODELS.find(m => m.id === model);

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-md animate-in fade-in zoom-in duration-200">
        <div className="flex justify-between items-center p-4 border-b">
          <h3 className="font-bold flex items-center gap-2 text-slate-800">
            <Settings className="w-5 h-5 text-blue-600" /> 
            AI Configuration
          </h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="p-6 space-y-6 overflow-y-auto max-h-[70vh]">
          {provider === 'Gemini' && (
            <div className="bg-blue-50 border border-blue-100 rounded p-3 text-xs text-blue-800">
               Gemini is configured to use the platform's free API key.
            </div>
          )}

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-500 mb-1.5 uppercase tracking-wider">Provider</label>
              <select 
                value={provider}
                onChange={e => handleProviderChange(e.target.value as ApiConfig['provider'])}
                className="w-full p-2.5 border border-slate-200 rounded-lg text-sm bg-white focus:ring-2 focus:ring-blue-500 outline-none transition-all font-medium"
              >
                <option value="Gemini">Google Gemini</option>
                <option value="Qwen">Alibaba Qwen (千问)</option>
                <option value="Doubao">ByteDance Doubao (豆包)</option>
                <option value="OpenAI-Compatible">OpenAI Compatible</option>
              </select>
            </div>

            {provider !== 'Gemini' && (
              <>
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1.5 uppercase tracking-wider">API Key</label>
                  <input 
                    type="password"
                    value={apiKey}
                    onChange={e => setApiKey(e.target.value)}
                    placeholder="Enter your API Key"
                    className="w-full p-2.5 border border-slate-200 rounded-lg text-sm bg-white focus:ring-2 focus:ring-blue-500 outline-none transition-all font-medium"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1.5 uppercase tracking-wider">Base URL</label>
                  <input 
                    type="text"
                    value={baseUrl}
                    onChange={e => setBaseUrl(e.target.value)}
                    placeholder="https://api.example.com/v1"
                    className="w-full p-2.5 border border-slate-200 rounded-lg text-sm bg-white focus:ring-2 focus:ring-blue-500 outline-none transition-all font-medium"
                  />
                </div>
              </>
            )}

            <div>
              <label className="block text-xs font-bold text-slate-500 mb-1.5 uppercase tracking-wider">Model Selection</label>
              <div className="space-y-2">
                {provider === 'OpenAI-Compatible' ? (
                  <input 
                    type="text"
                    value={model}
                    onChange={e => setModel(e.target.value)}
                    placeholder="Enter model name (e.g. gpt-4o)"
                    className="w-full p-2.5 border border-slate-200 rounded-lg text-sm bg-white focus:ring-2 focus:ring-blue-500 outline-none transition-all font-medium"
                  />
                ) : (
                  <select 
                    value={model} 
                    onChange={e => setModel(e.target.value)} 
                    className="w-full p-2.5 border border-slate-200 rounded-lg text-sm bg-white focus:ring-2 focus:ring-blue-500 outline-none transition-all font-medium"
                  >
                    {filteredModels.map(m => (
                      <option key={m.id} value={m.id}>{m.name}</option>
                    ))}
                  </select>
                )}
                
                {selectedModelInfo && (
                  <div className="flex gap-2 p-3 bg-slate-50 rounded-lg border border-slate-100">
                    <Info className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                    <p className="text-[11px] text-slate-500 leading-relaxed italic">
                      {selectedModelInfo.description}
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="p-4 border-t bg-slate-50 rounded-b-xl flex justify-end">
          <button 
            onClick={() => { onSave({ apiKey, model, provider, baseUrl }); onClose(); }}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg text-sm font-bold hover:bg-blue-700 transition-all shadow-md shadow-blue-200 active:scale-95"
          >
            Save Configuration
          </button>
        </div>
      </div>
    </div>
  );
};

export default SettingsModal;
