import React from 'react';
import { Project } from '../types';
import { Plus, BookOpen, Settings, FileText, Clock, LayoutTemplate, ArrowRight, Trash2 } from 'lucide-react';

interface Props {
  projects: Project[];
  onCreateProject: () => void;
  onOpenProject: (p: Project) => void;
  onDeleteProject: (id: string) => void;
  onOpenKB: () => void;
  onOpenSettings: () => void;
  onOpenTemplates: () => void;
}

const Dashboard: React.FC<Props> = ({ projects, onCreateProject, onOpenProject, onDeleteProject, onOpenKB, onOpenSettings, onOpenTemplates }) => {
  return (
    <div className="min-h-screen bg-[#F0F2F5] flex flex-col p-8 relative font-sans">
      {/* Header/Nav */}
      <div className="flex justify-between items-center mb-12">
         <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center shadow-lg shadow-blue-200">
               <FileText className="text-white w-6 h-6" />
            </div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Clinical Doc Studio</h1>
         </div>
         <button 
            onClick={onOpenSettings} 
            className="p-2.5 bg-white rounded-full shadow-sm hover:shadow-md border border-slate-200 text-slate-500 hover:text-blue-600 transition-all"
            title="Settings"
         >
            <Settings className="w-5 h-5" />
         </button>
      </div>

      <div className="w-full max-w-7xl mx-auto animate-in slide-in-from-bottom-4 duration-500">
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {/* Hero Action: New Project */}
          <div 
            onClick={onCreateProject} 
            className="md:col-span-2 bg-gradient-to-br from-blue-600 to-indigo-700 p-8 rounded-3xl shadow-xl shadow-blue-200/50 cursor-pointer hover:shadow-2xl hover:scale-[1.01] transition-all relative overflow-hidden group text-white"
          >
             <div className="relative z-10 flex flex-col h-full justify-between">
                <div>
                   <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center mb-6">
                      <Plus className="w-6 h-6 text-white" />
                   </div>
                   <h2 className="text-3xl font-bold mb-2">Create New Project</h2>
                   <p className="text-blue-100 max-w-md">Launch a new clinical trial workspace. AI-assisted extraction from protocols and synopses.</p>
                </div>
                <div className="flex items-center gap-2 font-bold mt-8 group-hover:gap-4 transition-all">
                   Start Wizard <ArrowRight className="w-5 h-5" />
                </div>
             </div>
             {/* Decorative Background */}
             <div className="absolute -right-10 -bottom-20 w-64 h-64 bg-white/10 rounded-full blur-3xl group-hover:bg-white/20 transition-all"></div>
          </div>

          {/* Quick Actions Grid */}
          <div className="grid grid-rows-2 gap-6">
              {/* KB Card */}
              <div 
                onClick={onOpenKB} 
                className="bg-white p-6 rounded-3xl shadow-sm hover:shadow-xl border border-slate-100 cursor-pointer transition-all hover:-translate-y-1 group flex items-center gap-4"
              >
                <div className="w-14 h-14 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
                   <BookOpen className="w-7 h-7" />
                </div>
                <div>
                   <h3 className="text-lg font-bold text-slate-800">Knowledge Base</h3>
                   <p className="text-slate-500 text-xs">Manage reference RAG</p>
                </div>
              </div>

               {/* Templates Card */}
               <div 
                onClick={onOpenTemplates} 
                className="bg-white p-6 rounded-3xl shadow-sm hover:shadow-xl border border-slate-100 cursor-pointer transition-all hover:-translate-y-1 group flex items-center gap-4"
              >
                <div className="w-14 h-14 bg-purple-50 text-purple-600 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
                   <LayoutTemplate className="w-7 h-7" />
                </div>
                 <div>
                   <h3 className="text-lg font-bold text-slate-800">Templates</h3>
                   <p className="text-slate-500 text-xs">Custom structures</p>
                </div>
              </div>
          </div>
        </div>

        {/* Recent Projects Section */}
        <h3 className="text-lg font-bold text-slate-700 mb-6 flex items-center gap-2">
            <Clock className="w-5 h-5 text-slate-400" /> Recent Projects
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {projects.length === 0 ? (
             <div className="col-span-full py-12 text-center bg-white rounded-3xl border border-dashed border-slate-300">
                <p className="text-slate-400 font-medium">No projects yet. Create your first one!</p>
             </div>
          ) : (
             projects.map(p => (
               <div 
                 key={p.id} 
                 className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md hover:border-blue-300 transition-all group relative"
               >
                 <div className="flex justify-between items-start mb-3">
                    <div 
                      onClick={() => onOpenProject(p)}
                      className="p-2 bg-slate-50 rounded-lg group-hover:bg-blue-50 transition-colors cursor-pointer"
                    >
                       <FileText className="w-5 h-5 text-slate-500 group-hover:text-blue-600" />
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full font-bold">
                         {p.documents.length} Docs
                      </span>
                      <button 
                        onClick={(e) => { e.stopPropagation(); onDeleteProject(p.id); }}
                        className="p-1.5 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-md transition-all opacity-0 group-hover:opacity-100"
                        title="Delete Project"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                 </div>
                 <div onClick={() => onOpenProject(p)} className="cursor-pointer">
                    <h4 className="font-bold text-slate-800 mb-1 truncate">{p.projectName}</h4>
                    <p className="text-xs text-slate-400">Edited {new Date(p.updatedAt).toLocaleDateString()}</p>
                 </div>
               </div>
             ))
          )}
        </div>

      </div>
    </div>
  );
};

export default Dashboard;