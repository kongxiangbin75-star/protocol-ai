import React, { useState, useEffect } from 'react';
import { KBItem } from '../types';
import { StorageService } from '../services/storage';
import { parseFile } from '../services/parser';
import { Folder, FileText, Trash2, Upload, ChevronLeft, Home, Loader2, Plus } from 'lucide-react';

interface Props {
  onBack: () => void;
}

const KnowledgeBase: React.FC<Props> = ({ onBack }) => {
  const [items, setItems] = useState<KBItem[]>([]);
  const [currentFolderId, setCurrentFolderId] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    loadItems();
  }, []);

  const loadItems = async () => {
    const data = await StorageService.getKBItems();
    setItems(data);
  };

  const currentItems = items
    .filter(i => i.parentId === currentFolderId)
    .sort((a, b) => (a.type === b.type ? a.name.localeCompare(b.name) : a.type === 'folder' ? -1 : 1));

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    try {
      const text = await parseFile(file);
      const newItem: KBItem = {
        id: Math.random().toString(36).substr(2, 9),
        name: file.name,
        type: 'file',
        parentId: currentFolderId,
        content: text,
        createdAt: Date.now()
      };
      await StorageService.addKBItem(newItem);
      await loadItems();
    } catch (err) {
      alert("Error parsing file: " + (err as Error).message);
    } finally {
      setUploading(false);
    }
  };

  const createFolder = async () => {
    const name = prompt("Folder Name:");
    if (!name) return;
    const newItem: KBItem = {
      id: Math.random().toString(36).substr(2, 9),
      name,
      type: 'folder',
      parentId: currentFolderId,
      createdAt: Date.now()
    };
    await StorageService.addKBItem(newItem);
    await loadItems();
  };

  const deleteItem = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm("Are you sure?")) return;
    await StorageService.deleteKBItem(id);
    await loadItems();
  };

  // Breadcrumbs logic
  const breadcrumbs = [];
  let tempId = currentFolderId;
  while (tempId) {
    const folder = items.find(i => i.id === tempId);
    if (folder) {
      breadcrumbs.unshift(folder);
      tempId = folder.parentId;
    } else {
      break;
    }
  }

  return (
    <div className="flex flex-col h-screen bg-white">
      <div className="h-16 border-b flex items-center px-6 justify-between bg-white">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
            <ChevronLeft className="w-5 h-5 text-slate-600" />
          </button>
          <h2 className="text-xl font-bold text-slate-800">Knowledge Base</h2>
        </div>
      </div>

      <div className="p-6 flex-1 overflow-hidden flex flex-col max-w-5xl mx-auto w-full">
        {/* Toolbar */}
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center text-sm text-slate-600 gap-2">
            <button 
              onClick={() => setCurrentFolderId(null)} 
              className={`flex items-center gap-1 hover:text-blue-600 ${!currentFolderId ? 'font-bold text-blue-600' : ''}`}
            >
              <Home className="w-4 h-4" /> Root
            </button>
            {breadcrumbs.map(b => (
              <React.Fragment key={b.id}>
                <span className="text-slate-300">/</span>
                <button 
                  onClick={() => setCurrentFolderId(b.id)}
                  className={`hover:text-blue-600 ${currentFolderId === b.id ? 'font-bold text-blue-600' : ''}`}
                >
                  {b.name}
                </button>
              </React.Fragment>
            ))}
          </div>

          <div className="flex gap-3">
            <button 
              onClick={createFolder} 
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-sm font-medium flex items-center gap-2 transition-colors"
            >
              <Plus className="w-4 h-4" /> New Folder
            </button>
            <label className={`px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium flex items-center gap-2 cursor-pointer transition-colors shadow-sm ${uploading ? 'opacity-70 pointer-events-none' : ''}`}>
              {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
              Upload PDF/Doc
              <input type="file" onChange={handleUpload} className="hidden" accept=".pdf,.docx" />
            </label>
          </div>
        </div>

        {/* File Grid */}
        <div className="flex-1 bg-slate-50 border border-slate-200 rounded-xl p-4 overflow-y-auto">
          {currentItems.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-slate-400">
              <Folder className="w-16 h-16 mb-4 text-slate-300" />
              <p>This folder is empty</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {currentItems.map(item => (
                <div 
                  key={item.id}
                  onClick={() => item.type === 'folder' && setCurrentFolderId(item.id)}
                  className="bg-white p-4 rounded-lg border border-slate-200 hover:border-blue-400 hover:shadow-md cursor-pointer transition-all group flex items-start justify-between"
                >
                  <div className="flex items-center gap-3 overflow-hidden">
                    <div className={`p-2 rounded-lg ${item.type === 'folder' ? 'bg-blue-50 text-blue-600' : 'bg-orange-50 text-orange-600'}`}>
                      {item.type === 'folder' ? <Folder className="w-5 h-5" /> : <FileText className="w-5 h-5" />}
                    </div>
                    <div className="min-w-0">
                      <p className="font-medium text-slate-700 truncate text-sm">{item.name}</p>
                      <p className="text-[10px] text-slate-400">
                        {new Date(item.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <button 
                    onClick={(e) => deleteItem(item.id, e)} 
                    className="text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity p-1"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default KnowledgeBase;