import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Project, ClinicalDocument, DocNode, KBItem, ApiConfig, DocumentVersion, Comment, Citation } from '../types';
import { StorageService } from '../services/storage';
import { CitationService } from '../services/citationService';
import { generateSectionContent, critiqueSectionContent, refineText } from '../services/gemini';
import { 
  ChevronLeft, Sidebar, Save, Zap, BookOpen, 
  CheckCircle, Loader2, Sparkles, PanelRightOpen, PanelRightClose,
  Plus, Trash2, Edit2, History, ShieldCheck, Download, FileText,
  Bold, Italic, Underline, AlignLeft, AlignCenter, AlignRight, AlignJustify,
  List, ListOrdered, Table as TableIcon, Image as ImageIcon, Link as LinkIcon,
  MessageSquarePlus, Undo, Redo, Highlighter, Type, Heading1, Heading2, MessageSquare,
  Indent, Outdent, Subscript, Superscript, Eraser, Printer, Eye, GripVertical, 
  MoreHorizontal, ChevronDown, Check, Layout, Calendar, User, Flag, ArrowLeft, Columns,
  Strikethrough
} from 'lucide-react';

// Declare html-docx-js for TypeScript
declare const htmlDocx: any;
declare const saveAs: any;

interface Props {
  project: Project;
  initialDoc: ClinicalDocument;
  onBack: () => void;
  apiConfig: ApiConfig;
  onUpdateDocument: (doc: ClinicalDocument) => void;
}

interface NodeItemProps {
  node: DocNode;
  depth?: number;
  activeNodeId: string | null;
  hoverNodeId: string | null;
  docData: Record<string, string>;
  selectionMode: boolean;
  selectedIds: Set<string>;
  onHover: (id: string | null) => void;
  onActivate: (id: string) => void;
  onAdd: (id: string) => void;
  onRename: (id: string) => void;
  onDelete: (id: string) => void;
  onToggleSelect: (id: string) => void;
}

const NodeItem: React.FC<NodeItemProps> = ({ 
  node, depth = 0, activeNodeId, hoverNodeId, docData, selectionMode, selectedIds,
  onHover, onActivate, onAdd, onRename, onDelete, onToggleSelect
}) => (
  <div 
    onMouseEnter={() => onHover(node.id)}
    onMouseLeave={() => onHover(null)}
    className="group relative"
  >
    <div 
      onClick={() => {
          if (selectionMode) onToggleSelect(node.id);
          else onActivate(node.id);
      }}
      className={`
        py-1.5 pr-2 text-sm cursor-pointer border-l-[3px] transition-colors flex justify-between items-center
        ${activeNodeId === node.id && !selectionMode
          ? 'border-blue-600 bg-blue-50/50 text-blue-700 font-semibold' 
          : 'border-transparent text-slate-600 hover:bg-slate-100'}
        ${selectedIds.has(node.id) && selectionMode ? 'bg-blue-100' : ''}
      `}
      style={{ paddingLeft: `${depth * 14 + 12}px` }}
    >
      <div className="flex items-center gap-2 flex-1 overflow-hidden">
          {selectionMode && (
              <input 
                type="checkbox" 
                checked={selectedIds.has(node.id)} 
                onChange={() => onToggleSelect(node.id)}
                onClick={(e) => e.stopPropagation()}
                className="w-3.5 h-3.5 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
              />
          )}
          <span className="truncate flex-1 font-medium">{node.title}</span>
      </div>
      
      <div className="flex items-center gap-1">
         {docData?.[node.id] && <CheckCircle className="w-3.5 h-3.5 text-emerald-500 mr-1" />}
         {(hoverNodeId === node.id || activeNodeId === node.id) && !selectionMode && (
           <div className="flex gap-1 opacity-100 transition-opacity bg-white/90 shadow-sm rounded px-1 border border-slate-100" onClick={e => e.stopPropagation()}>
             <button onClick={() => onAdd(node.id)} title="Add Sub-section" className="p-1 hover:text-blue-600 hover:bg-blue-50 rounded"><Plus className="w-3 h-3" /></button>
             <button onClick={() => onRename(node.id)} title="Rename" className="p-1 hover:text-orange-600 hover:bg-orange-50 rounded"><Edit2 className="w-3 h-3" /></button>
             <button onClick={() => onDelete(node.id)} title="Delete" className="p-1 hover:text-red-600 hover:bg-red-50 rounded"><Trash2 className="w-3 h-3" /></button>
           </div>
         )}
      </div>
    </div>
    {node.children?.map(child => (
      <NodeItem 
        key={child.id} 
        node={child} 
        depth={depth + 1}
        activeNodeId={activeNodeId}
        hoverNodeId={hoverNodeId}
        docData={docData}
        selectionMode={selectionMode}
        selectedIds={selectedIds}
        onHover={onHover}
        onActivate={onActivate}
        onAdd={onAdd}
        onRename={onRename}
        onDelete={onDelete}
        onToggleSelect={onToggleSelect}
      />
    ))}
  </div>
);

// --- HELPER COMPONENTS ---

const ToolbarGroup: React.FC<{ label: string; children: React.ReactNode }> = ({ label, children }) => (
  <div className="flex flex-col items-center px-2 border-r border-slate-200 h-full justify-between py-1 shrink-0">
    <div className="flex gap-1 items-center justify-center flex-1">{children}</div>
    <span className="text-[10px] text-slate-400 font-medium tracking-wide mt-1">{label}</span>
  </div>
);

const RibbonButton: React.FC<{ 
  icon: React.ReactNode; 
  label?: string; 
  onClick: () => void; 
  active?: boolean;
  title?: string;
  large?: boolean;
  color?: string;
}> = ({ icon, label, onClick, active, title, large, color }) => (
  <button 
    onMouseDown={(e) => { e.preventDefault(); onClick(); }}
    className={`
      flex flex-col items-center justify-center rounded transition-all
      ${active ? 'bg-blue-100 text-blue-700 shadow-inner ring-1 ring-blue-200' : 'hover:bg-slate-100 text-slate-700'}
      ${large ? 'p-2 min-w-[50px] h-full gap-1' : 'p-1 min-w-[28px]'}
    `}
    title={title}
  >
    <div className={`${color || 'text-current'}`}>{icon}</div>
    {label && <span className={`${large ? 'text-[11px] font-medium' : 'text-[10px] mt-0.5'}`}>{label}</span>}
  </button>
);

// Custom Dropdown to prevent focus loss on editor
const CustomSelect: React.FC<{ 
    options: { label: string, value: string }[], 
    value: string, 
    onChange: (val: string) => void,
    width?: string 
}> = ({ options, value, onChange, width = "w-24" }) => {
    const [isOpen, setIsOpen] = useState(false);
    return (
        <div className={`relative ${width} h-6 text-xs z-50`}>
            <div 
                onMouseDown={(e) => { e.preventDefault(); setIsOpen(!isOpen); }}
                className="w-full h-full border rounded px-1 flex items-center justify-between cursor-pointer bg-slate-50 hover:bg-slate-100"
            >
                <span className="truncate">{options.find(o => o.value === value)?.label || value}</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
            </div>
            {isOpen && (
                <div className="absolute top-full left-0 w-full bg-white border shadow-lg rounded z-50 max-h-64 overflow-y-auto mt-1">
                    {options.map(opt => (
                        <div 
                            key={opt.value}
                            onMouseDown={(e) => { e.preventDefault(); onChange(opt.value); setIsOpen(false); }}
                            className="px-2 py-1.5 hover:bg-blue-50 cursor-pointer flex justify-between items-center"
                        >
                            <span>{opt.label}</span>
                            {opt.value === value && <Check className="w-3 h-3 text-blue-500"/>}
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

const ColorPicker: React.FC<{ icon: React.ReactNode, defaultColor: string, onChange: (val: string) => void, label?: string }> = ({ icon, defaultColor, onChange, label }) => {
  const colors = [
    '#000000', '#444444', '#666666', '#999999', '#cccccc', '#eeeeee', '#f3f3f3', '#ffffff',
    '#ef4444', '#f97316', '#facc15', '#22c55e', '#3b82f6', '#8b5cf6', '#ec4899', '#d946ef',
    '#991b1b', '#9a3412', '#854d0e', '#166534', '#1e40af', '#5b21b6', '#86198f', '#701a75'
  ];
  return (
    <div className="flex flex-col items-center justify-center group relative cursor-pointer hover:bg-slate-100 rounded p-1">
       <div className="flex items-center gap-1" onMouseDown={e => { e.preventDefault(); onChange(defaultColor); }}>
          <div className="flex flex-col items-center">
            {icon}
            {label && <div className="h-1 w-full mt-0.5" style={{ backgroundColor: label }}></div>}
          </div>
          <ChevronDown className="w-2 h-2 text-slate-400" />
       </div>
       <div className="absolute top-full left-0 bg-white border shadow-xl p-2 rounded grid grid-cols-8 gap-1 z-50 opacity-0 group-hover:opacity-100 invisible group-hover:visible transition-all w-48 mt-1">
          {colors.map(c => (
            <div 
              key={c} 
              onMouseDown={(e) => { e.preventDefault(); onChange(c); }}
              className="w-4 h-4 rounded border border-slate-200 cursor-pointer hover:scale-125 transition-transform" 
              style={{ backgroundColor: c }} 
              title={c}
            />
          ))}
       </div>
    </div>
  );
};

const Workspace: React.FC<Props> = ({ project, initialDoc, onBack, apiConfig, onUpdateDocument }) => {
  const [doc, setDoc] = useState<ClinicalDocument>(initialDoc);
  const [activeNodeId, setActiveNodeId] = useState<string | null>(null);
  const [kbItems, setKbItems] = useState<KBItem[]>([]);
  const [selectedKbIds, setSelectedKbIds] = useState<Set<string>>(new Set());
  
  // UI State
  const [generating, setGenerating] = useState(false);
  const [reviewing, setReviewing] = useState(false);
  const [leftOpen, setLeftOpen] = useState(true);
  const [rightOpen, setRightOpen] = useState(true);
  const [hoverNodeId, setHoverNodeId] = useState<string | null>(null);
  
  // Ribbon State
  const [ribbonTab, setRibbonTab] = useState<'home' | 'insert' | 'layout' | 'review' | 'view'>('home');
  const [sidebarTab, setSidebarTab] = useState<'info' | 'comments' | 'review' | 'batch' | 'citations'>('info');
  const [activeFormats, setActiveFormats] = useState<Record<string, boolean>>({});
  const [viewMode, setViewMode] = useState<'section' | 'document'>('section');
  
  // Page Info
  const [pageCount, setPageCount] = useState(1);
  const [currentPage, setCurrentPage] = useState(1);
  
  // QC/Review State
  const [critique, setCritique] = useState<string>("");
  const [hoveredCommentId, setHoveredCommentId] = useState<string | null>(null);

  // Batch Update State
  const [batchSelectedIds, setBatchSelectedIds] = useState<Set<string>>(new Set());
  const [selectionMode, setSelectionMode] = useState(false);
  const [findText, setFindText] = useState("");
  const [replaceText, setReplaceText] = useState("");

  // Citation State
  const [citationQuery, setCitationQuery] = useState("");
  const [citationResults, setCitationResults] = useState<Citation[]>([]);
  const [searchingCitations, setSearchingCitations] = useState(false);
  const [citationSource, setCitationSource] = useState<'pubmed' | 'clinicaltrials'>('pubmed');

  // Helper to flatten tree for batch selection
  const flattenNodes = (nodes: DocNode[]): DocNode[] => {
    let flat: DocNode[] = [];
    nodes.forEach(n => {
      flat.push(n);
      if (n.children) flat = flat.concat(flattenNodes(n.children));
    });
    return flat;
  };
  const allNodes = useMemo(() => flattenNodes(doc.docTree), [doc.docTree]);

  const toggleSelection = (id: string) => {
      const newSet = new Set(batchSelectedIds);
      if (newSet.has(id)) newSet.delete(id);
      else newSet.add(id);
      setBatchSelectedIds(newSet);
  };

  const handleSelectAll = () => {
      if (batchSelectedIds.size === allNodes.length) {
          setBatchSelectedIds(new Set()); // Deselect all
      } else {
          setBatchSelectedIds(new Set(allNodes.map(n => n.id))); // Select all
      }
  };

  const handleBatchUpdate = () => {
    if (!findText) return alert("Please enter text to find.");
    if (batchSelectedIds.size === 0) return alert("Please select at least one section.");

    if (!confirm(`Replace "${findText}" with "${replaceText}" in ${batchSelectedIds.size} sections?`)) return;
    
    const newDocData = { ...doc.docData };
    let count = 0;

    batchSelectedIds.forEach(id => {
        let content = "";
        // Use current editor content if it's the active node
        if (id === activeNodeId && editorRef.current) {
            content = editorRef.current.innerHTML;
        } else {
            content = newDocData[id] || "";
        }

        if (content.includes(findText)) {
            // Global replace
            const regex = new RegExp(findText.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g');
            newDocData[id] = content.replace(regex, replaceText);
            count++;
        }
    });

    setDoc(prev => ({ ...prev, docData: newDocData }));
    alert(`Updated ${count} sections.`);
  };

  // Refs
  const editorRef = useRef<HTMLDivElement>(null);
  const centerAreaRef = useRef<HTMLDivElement>(null);

  // Initialize styleWithCSS
  useEffect(() => {
    if (typeof window !== 'undefined' && window.document) {
      try {
        window.document.execCommand('styleWithCSS', false, 'true');
      } catch (e) {}
    }
  }, []);

  // Update Page Info
  const updatePageInfo = () => {
    if (editorRef.current) {
      const height = editorRef.current.scrollHeight + 192; // Content + Margins
      const pages = Math.max(1, Math.ceil(height / 1056));
      setPageCount(pages);
    }
  };

  const handleScroll = () => {
    if (centerAreaRef.current) {
      const scrollTop = centerAreaRef.current.scrollTop;
      const current = Math.max(1, Math.ceil((scrollTop + 528) / 1056));
      setCurrentPage(current);
    }
  };

  useEffect(() => {
    updatePageInfo();
    const handleSelectionChange = () => {
      checkFormats();
    };
    window.document.addEventListener('selectionchange', handleSelectionChange);
    return () => window.document.removeEventListener('selectionchange', handleSelectionChange);
  }, [doc.docData, activeNodeId]);

  // Save content before switching nodes
  const handleNodeSelect = (id: string) => {
    if (editorRef.current && activeNodeId) {
      const content = editorRef.current.innerHTML;
      setDoc(prev => ({
        ...prev,
        docData: { ...prev.docData, [activeNodeId]: content }
      }));
    }
    setActiveNodeId(id);
  };

  useEffect(() => {
    if (editorRef.current) {
      const highlights = editorRef.current.querySelectorAll('.comment-highlight');
      highlights.forEach(h => {
        if (h.getAttribute('data-comment-id') === hoveredCommentId) {
          h.setAttribute('data-hovered', 'true');
        } else {
          h.removeAttribute('data-hovered');
        }
      });
    }
  }, [hoveredCommentId]);

  // Sync content to editor when activeNodeId changes or docData updates externally
  useEffect(() => {
    if (editorRef.current && activeNodeId) {
      const currentContent = editorRef.current.innerHTML;
      const newContent = doc.docData[activeNodeId] || '';
      
      // Only update if content is different AND we are not currently editing (focused)
      // This prevents overwriting user input with stale state during re-renders
      if (currentContent !== newContent && document.activeElement !== editorRef.current) {
        editorRef.current.innerHTML = newContent;
      }
    }
  }, [activeNodeId, doc.docData]);

  useEffect(() => {
    if (doc.docTree.length > 0 && !activeNodeId) {
      setActiveNodeId(doc.docTree[0].id);
    }
    setDoc(d => ({ ...d, versions: d.versions || [], comments: d.comments || {} }));
  }, []);

  useEffect(() => {
    StorageService.getKBItems().then(items => { setKbItems(items.filter(i => i.type === 'file')); });
  }, []);

  // Update Ribbon State on Selection Change
  const checkFormats = () => {
    // Safely use window.document to ensure we target the global DOM
    if (typeof window === 'undefined' || !window.document) return;
    
    try {
      setActiveFormats({
        bold: window.document.queryCommandState('bold'),
        italic: window.document.queryCommandState('italic'),
        underline: window.document.queryCommandState('underline'),
        subscript: window.document.queryCommandState('subscript'),
        superscript: window.document.queryCommandState('superscript'),
        justifyLeft: window.document.queryCommandState('justifyLeft'),
        justifyCenter: window.document.queryCommandState('justifyCenter'),
        justifyRight: window.document.queryCommandState('justifyRight'),
        insertUnorderedList: window.document.queryCommandState('insertUnorderedList'),
        insertOrderedList: window.document.queryCommandState('insertOrderedList'),
      });
    } catch (e) {
      // Ignore errors if queryCommandState is not supported or active
    }
  };

  useEffect(() => {
    const handleSelection = () => checkFormats();
    window.document.addEventListener('selectionchange', handleSelection);
    return () => window.document.removeEventListener('selectionchange', handleSelection);
  }, []);

  // Completion Stats
  const completionStats = useMemo(() => {
    let total = 0;
    let filled = 0;
    const traverse = (nodes: DocNode[]) => {
      nodes.forEach(n => {
        if (!n.children || n.children.length === 0) {
           total++;
           const content = doc.docData[n.id] || "";
           if (content.replace(/<[^>]*>/g, '').trim().length > 0) filled++;
        } else {
           traverse(n.children);
        }
      });
    };
    traverse(doc.docTree);
    return { total, filled, percent: total === 0 ? 0 : Math.round((filled / total) * 100) };
  }, [doc]);

  const findNode = (nodes: DocNode[], id: string): DocNode | null => {
    for (const node of nodes) {
      if (node.id === id) return node;
      if (node.children) {
        const found = findNode(node.children, id);
        if (found) return found;
      }
    }
    return null;
  };

  const activeNode = activeNodeId ? findNode(doc.docTree || [], activeNodeId) : null;

  const handleCitationSearch = async () => {
    if (!citationQuery.trim()) return;
    setSearchingCitations(true);
    try {
      const results = citationSource === 'pubmed' 
        ? await CitationService.searchPubMed(citationQuery)
        : await CitationService.searchClinicalTrials(citationQuery);
      setCitationResults(results);
    } catch (e) {
      console.error(e);
    } finally {
      setSearchingCitations(false);
    }
  };

  const insertCitation = (citation: Citation) => {
    const citationText = `[${citation.authors?.[0] || 'N/A'}, ${citation.year || 'n.d.'}]`;
    const citationHtml = `<a href="${citation.url}" target="_blank" class="text-blue-600 hover:underline font-medium" title="${citation.title}">${citationText}</a>`;
    execCmd('insertHTML', citationHtml);
  };

  const changeCase = (mode: 'upper' | 'lower' | 'sentence' | 'capitalize') => {
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0) return;
    const text = selection.toString();
    if (!text) return;

    let newText = text;
    if (mode === 'upper') newText = text.toUpperCase();
    if (mode === 'lower') newText = text.toLowerCase();
    if (mode === 'sentence') newText = text.charAt(0).toUpperCase() + text.slice(1).toLowerCase();
    if (mode === 'capitalize') newText = text.replace(/\b\w/g, l => l.toUpperCase());

    window.document.execCommand('insertText', false, newText);
    handleContentChange();
  };

  const setLineHeight = (height: string) => {
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0) return;
    let node = selection.anchorNode;
    if (node?.nodeType === 3) node = node.parentNode;
    
    // Find closest container that is likely a paragraph or section content
    let block = node as HTMLElement;
    while(block && !['P', 'DIV', 'H1', 'H2', 'H3', 'LI', 'TD'].includes(block.tagName)) {
        if (block.getAttribute('contenteditable') === 'true') break;
        block = block.parentElement as HTMLElement;
    }
    
    if (block) {
        block.style.lineHeight = height;
        handleContentChange();
    }
  };

  // --- EDITOR COMMANDS ---
  const execCmd = (command: string, value: string | undefined = undefined) => {
    // Restore focus if lost (important for non-button inputs)
    if (window.document.activeElement?.getAttribute('contenteditable') !== 'true') {
        editorRef.current?.focus();
    }

    // Special handling for colors
    if (command === 'hiliteColor') {
       window.document.execCommand('styleWithCSS', false, 'true');
       const isFirefox = typeof window !== 'undefined' && window.navigator.userAgent.toLowerCase().includes('firefox');
       window.document.execCommand(isFirefox ? 'hiliteColor' : 'backColor', false, value);
    } else if (command === 'foreColor') {
       window.document.execCommand('styleWithCSS', false, 'true');
       window.document.execCommand('foreColor', false, value);
    } else {
       // Mutually exclusive superscript/subscript
       if (command === 'superscript') {
           if (window.document.queryCommandState('subscript')) {
               window.document.execCommand('subscript', false, undefined);
           }
       } else if (command === 'subscript') {
           if (window.document.queryCommandState('superscript')) {
               window.document.execCommand('superscript', false, undefined);
           }
       }
       window.document.execCommand(command, false, value);
    }

    if (editorRef.current && activeNodeId) {
      handleContentChange();
      updatePageInfo();
    }
    checkFormats(); // Update button states immediately
  };

  const handleContentChange = () => {
    if (editorRef.current && activeNodeId) {
      setDoc(d => ({ ...d, docData: { ...d.docData, [activeNodeId]: editorRef.current!.innerHTML } }));
    }
  };

  // --- INSERT FUNCTIONS ---
  const insertTable = () => {
    const html = `
      <table style="border-collapse: collapse; width: 100%; margin: 15px 0; border: 1px solid #cbd5e1;">
        <tbody>
          <tr>
            <td style="border: 1px solid #cbd5e1; padding: 10px;">Cell 1</td>
            <td style="border: 1px solid #cbd5e1; padding: 10px;">Cell 2</td>
          </tr>
          <tr>
            <td style="border: 1px solid #cbd5e1; padding: 10px;">Cell 3</td>
            <td style="border: 1px solid #cbd5e1; padding: 10px;">Cell 4</td>
          </tr>
        </tbody>
      </table><p><br/></p>
    `;
    execCmd('insertHTML', html);
  };

  const insertImagePlaceholder = () => {
     execCmd('insertHTML', `<div style="background:#f8fafc; border:2px dashed #cbd5e1; border-radius: 8px; padding:40px; text-align:center; margin: 20px 0; color:#64748b; font-weight:bold; font-family: sans-serif;">
       [ FIGURE PLACEHOLDER ]
     </div><p><br/></p>`);
  };

  const insertLink = () => {
    const url = prompt("Enter URL:", "http://");
    if(url) execCmd('createLink', url);
  };

  // --- COMMENTING ---
  const addComment = () => {
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0 || selection.toString().length === 0) {
      alert("Please select text to comment on.");
      return;
    }
    if (!activeNodeId) return;

    const selectedText = selection.toString();
    const commentId = 'comment-' + Math.random().toString(36).substr(2, 9);
    
    const commentText = prompt("Enter comment:");
    if (!commentText) return;

    // Use execCommand to wrap with a temporary marker, then replace it
    // or use range.surroundContents if safe
    const range = selection.getRangeAt(0);
    const span = document.createElement('span');
    span.className = 'comment-highlight bg-yellow-200/50 border-b-2 border-yellow-400 cursor-pointer transition-all hover:bg-yellow-300/70';
    span.setAttribute('data-comment-id', commentId);
    span.title = "Click to view comment";
    
    try {
      range.surroundContents(span);
    } catch (e) {
      // Fallback for complex selections
      document.execCommand('hiliteColor', false, '#fef08a');
    }

    const newComment: Comment = {
      id: commentId,
      author: "User",
      text: commentText,
      selectedText: selectedText,
      timestamp: Date.now(),
      resolved: false
    };

    setDoc(prev => ({
        ...prev,
        comments: {
            ...prev.comments,
            [activeNodeId]: [...(prev.comments?.[activeNodeId] || []), newComment]
        }
    }));
    
    handleContentChange(); // Sync to docData
    setSidebarTab('comments');
    setRightOpen(true);
  };

  const deleteComment = (commentId: string) => {
     if(!activeNodeId) return;
     
     // Remove highlight from editor if present
     if (editorRef.current) {
        const span = editorRef.current.querySelector(`span[data-comment-id="${commentId}"]`);
        if (span) {
           const parent = span.parentNode;
           while (span.firstChild) parent?.insertBefore(span.firstChild, span);
           parent?.removeChild(span);
        }
     }

     setDoc(prev => ({
         ...prev,
         comments: {
             ...prev.comments,
             [activeNodeId]: prev.comments?.[activeNodeId]?.filter(c => c.id !== commentId) || []
         }
     }));
     handleContentChange();
  };

  const scrollToComment = (commentId: string) => {
    if (editorRef.current) {
      const span = editorRef.current.querySelector(`span[data-comment-id="${commentId}"]`);
      if (span) {
        span.scrollIntoView({ behavior: 'smooth', block: 'center' });
        // Visual feedback
        (span as HTMLElement).classList.add('ring-4', 'ring-blue-400', 'ring-opacity-50');
        setTimeout(() => {
          (span as HTMLElement).classList.remove('ring-4', 'ring-blue-400', 'ring-opacity-50');
        }, 2000);
      }
    }
  };

  // --- AI ACTIONS ---
  const handleGenerate = async () => {
    // Determine which nodes to generate for
    let nodesToProcess: DocNode[] = [];
    
    if (selectionMode && batchSelectedIds.size > 0) {
        nodesToProcess = allNodes.filter(n => batchSelectedIds.has(n.id));
    } else if (activeNode && activeNodeId) {
        nodesToProcess = [activeNode];
    }

    if (nodesToProcess.length === 0) {
        alert("Please select at least one section to generate content for.");
        return;
    }

    setGenerating(true);
    try {
      const kbContext = kbItems.filter(k => selectedKbIds.has(k.id)).map(d => d.content).join('\n\n');
      
      for (const node of nodesToProcess) {
          const docContext = Object.values(doc.docData).join('\n').substring(0, 10000); 
          
          const content = await generateSectionContent(
              apiConfig, 
              node.title, 
              project.projectName, 
              project.variables, 
              "Standard ICH-GCP", 
              kbContext, 
              docContext
          );
          
          setDoc(prev => {
              const currentContent = prev.docData[node.id] || "";
              const newContent = currentContent + (currentContent ? "<br/>" : "") + content;
              return { 
                  ...prev, 
                  docData: { ...prev.docData, [node.id]: newContent } 
              };
          });

          // Small delay if processing multiple
          if (nodesToProcess.length > 1) {
              await new Promise(r => setTimeout(r, 300));
          }
      }
    } catch (e) { 
        console.error(e);
        alert(`Generation failed: ${(e as Error).message}`); 
    } finally { setGenerating(false); }
  };


  const handleReview = async (mode: 'gcp' | 'consistency' | 'clarity') => {
    if (!activeNodeId) return;
    setReviewing(true);
    setSidebarTab('review');
    setRightOpen(true);
    try {
        const currentContent = editorRef.current ? editorRef.current.innerHTML : (doc.docData[activeNodeId] || "");
        const res = await critiqueSectionContent(apiConfig, activeNode?.title || "", currentContent, project.variables, mode);
        setCritique(res);
    } catch(e) { setCritique("Error."); } finally { setReviewing(false); }
  };

  const handleExportWord = () => {
    if (typeof htmlDocx === 'undefined') return alert("Export library loading...");
    let htmlContent = `<html><head><style>body { font-family: 'Times New Roman'; }</style></head><body>`;
    const traverse = (nodes: DocNode[], depth = 1) => {
      nodes.forEach(node => {
        const content = doc.docData[node.id] || "";
        htmlContent += `<h${depth}>${node.title}</h${depth}>${content}`;
        if (node.children) traverse(node.children, depth + 1);
      });
    };
    traverse(doc.docTree);
    htmlContent += "</body></html>";
    const converted = htmlDocx.asBlob(htmlContent);
    saveAs(converted, `${project.projectName}_${doc.type}.docx`);
  };

  const activeComments = activeNodeId ? (doc.comments?.[activeNodeId] || []) : [];

  const handleMetaUpdate = (field: 'status' | 'assignee' | 'dueDate' | 'priority', value: any) => {
      const updated = { ...doc, [field]: value };
      setDoc(updated);
      onUpdateDocument(updated); // Sync immediately
  };

  return (
    <div className="flex flex-col h-screen bg-[#EBECEF] relative overflow-hidden font-sans">
      
      {/* 1. TOP TITLE BAR (MANAGEMENT HEADER) */}
      <header className="h-14 bg-[#2B579A] flex items-center justify-between px-4 z-20 shrink-0 shadow-sm text-white">
        <div className="flex items-center gap-4">
           <button onClick={onBack} className="hover:bg-white/10 p-1.5 rounded-full transition-colors flex items-center text-xs font-medium gap-1 text-white/90">
             <ChevronLeft className="w-5 h-5" /> Back
           </button>
           <div className="h-8 w-px bg-white/20"></div>
           <div>
              <h1 className="text-sm font-bold leading-tight">{doc.title}</h1>
              <div className="text-[10px] opacity-80 leading-tight">{project.projectName}</div>
           </div>
        </div>

        {/* METADATA CONTROLS */}
        <div className="flex items-center gap-3">
             <div className="flex items-center bg-black/20 rounded-md p-0.5">
                 <select 
                    value={doc.status} 
                    onChange={(e) => handleMetaUpdate('status', e.target.value)}
                    className="bg-transparent text-white text-xs font-bold uppercase px-2 py-1 outline-none cursor-pointer"
                 >
                     <option value="draft" className="text-slate-800">Draft</option>
                     <option value="review" className="text-slate-800">Review</option>
                     <option value="qc" className="text-slate-800">QC</option>
                     <option value="final" className="text-slate-800">Final</option>
                 </select>
             </div>
             <div className="flex items-center gap-2 text-xs">
                 <div className="flex flex-col items-end">
                     <span className="text-[9px] opacity-60 uppercase font-bold">Assignee</span>
                     <div className="flex items-center gap-1 cursor-pointer hover:bg-white/10 px-1 rounded" onClick={() => handleMetaUpdate('assignee', prompt('Assign to:', doc.assignee))}>
                         <User className="w-3 h-3"/> {doc.assignee || 'Unassigned'}
                     </div>
                 </div>
                 <div className="flex flex-col items-end">
                     <span className="text-[9px] opacity-60 uppercase font-bold">Due Date</span>
                     <div className="flex items-center gap-1 cursor-pointer hover:bg-white/10 px-1 rounded" onClick={() => {
                        const current = doc.dueDate ? new Date(doc.dueDate).toISOString().split('T')[0] : "";
                        const date = prompt("Due Date (YYYY-MM-DD):", current);
                        if (date) {
                           const ts = new Date(date).getTime();
                           if (!isNaN(ts)) handleMetaUpdate('dueDate', ts);
                        }
                     }}>
                         <Calendar className="w-3 h-3"/> {doc.dueDate ? new Date(doc.dueDate).toLocaleDateString() : 'Set Date'}
                     </div>
                 </div>
             </div>
             
             <div className="h-8 w-px bg-white/20"></div>

             <button onClick={() => { onUpdateDocument({...doc, updatedAt: Date.now()}); }} className="hover:bg-white/10 p-2 rounded flex items-center gap-1.5 text-xs font-medium transition-colors"><Save className="w-4 h-4" /> Save</button>
             <button onClick={handleExportWord} className="bg-white text-[#2B579A] px-3 py-1.5 rounded text-xs font-bold hover:bg-slate-100 transition-colors flex items-center gap-1"><Download className="w-3.5 h-3.5" /> Export</button>
             <div className="h-8 w-px bg-white/20"></div>
             <button onClick={() => setRightOpen(!rightOpen)} className="hover:bg-white/10 p-2 rounded text-white/90 transition-colors" title="Toggle Inspector">
                  {rightOpen ? <PanelRightClose className="w-5 h-5" /> : <PanelRightOpen className="w-5 h-5" />}
             </button>
        </div>
      </header>

      {/* 2. RIBBON TOOLBAR */}
      <div className="bg-white border-b shadow-sm z-10 flex flex-col shrink-0">
        {/* Ribbon Tabs */}
        <div className="flex px-1 bg-[#F3F4F6] border-b border-slate-200">
           {['Home', 'Insert', 'Layout', 'Review', 'View'].map(tab => (
             <button 
                key={tab} 
                onClick={() => setRibbonTab(tab.toLowerCase() as any)}
                className={`px-6 py-1.5 text-xs font-medium rounded-t-lg transition-colors mt-1 mx-0.5 
                  ${ribbonTab === tab.toLowerCase() 
                    ? 'bg-white text-[#2B579A] border-t border-l border-r border-slate-200 shadow-[0_-2px_4px_rgba(0,0,0,0.02)] relative top-[1px]' 
                    : 'text-slate-600 hover:bg-slate-200'}`}
             >
               {tab}
             </button>
           ))}
           <div className="ml-auto flex items-center pr-2 py-1 gap-2">
              <button 
                  onClick={handleGenerate} 
                  disabled={generating}
                  className="px-4 py-1.5 bg-gradient-to-r from-indigo-500 to-purple-500 text-white rounded-md text-xs font-bold flex items-center gap-2 hover:shadow-md transition-all disabled:opacity-50"
                  title={selectionMode && batchSelectedIds.size > 0 ? `Generate content for ${batchSelectedIds.size} selected sections` : "Generate content for current section"}
              >
                  {generating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />} 
                  {selectionMode && batchSelectedIds.size > 0 ? `AI Writer (${batchSelectedIds.size})` : "AI Writer"}
              </button>
           </div>
        </div>

        {/* Ribbon Content Panel - No overflow-x-auto to prevent dropdown clipping */}
        <div className="h-24 bg-white flex items-center px-4 whitespace-nowrap overflow-visible">
           
           {/* HOME TAB */}
           {ribbonTab === 'home' && (
             <>
               <ToolbarGroup label="Clipboard">
                  <RibbonButton icon={<Undo className="w-4 h-4"/>} title="Undo" onClick={() => execCmd('undo')} />
                  <RibbonButton icon={<Redo className="w-4 h-4"/>} title="Redo" onClick={() => execCmd('redo')} />
                  <RibbonButton icon={<Eraser className="w-4 h-4"/>} title="Clear Formatting" onClick={() => execCmd('removeFormat')} />
               </ToolbarGroup>

               <ToolbarGroup label="Font">
                  <div className="flex flex-col gap-1">
                     <div className="flex gap-1 z-50">
                        {/* Custom Selects to prevent focus loss */}
                        <CustomSelect 
                            width="w-32"
                            value={typeof window !== 'undefined' ? (window.document.queryCommandValue('fontName')?.replace(/['"]/g, '') || 'Merriweather') : 'Merriweather'}
                            options={[
                                { label: 'Arial', value: 'Arial' },
                                { label: 'Calibri', value: 'Calibri' },
                                { label: 'Cambria', value: 'Cambria' },
                                { label: 'Courier New', value: 'Courier New' },
                                { label: 'Georgia', value: 'Georgia' },
                                { label: 'Inter', value: 'Inter' },
                                { label: 'Merriweather', value: 'Merriweather' },
                                { label: 'Times New Roman', value: 'Times New Roman' },
                                { label: 'Verdana', value: 'Verdana' },
                            ]}
                            onChange={v => execCmd('fontName', v)}
                        />
                         <CustomSelect 
                            width="w-16"
                            value={typeof window !== 'undefined' ? (window.document.queryCommandValue('fontSize') || '3') : '3'}
                            options={[
                                {label:'8pt',value:'1'},{label:'10pt',value:'2'},{label:'12pt',value:'3'},
                                {label:'14pt',value:'4'},{label:'18pt',value:'5'},{label:'24pt',value:'6'},{label:'36pt',value:'7'}
                            ]}
                            onChange={v => execCmd('fontSize', v)}
                        />
                        <CustomSelect 
                            width="w-10"
                            value="Aa"
                            options={[
                                {label:'Sentence case',value:'sentence'},
                                {label:'lowercase',value:'lower'},
                                {label:'UPPERCASE',value:'upper'},
                                {label:'Capitalize Each Word',value:'capitalize'}
                            ]}
                            onChange={v => changeCase(v as any)}
                        />
                     </div>
                     <div className="flex gap-0.5">
                        <RibbonButton icon={<Bold className="w-3.5 h-3.5"/>} onClick={() => execCmd('bold')} title="Bold" active={activeFormats.bold} />
                        <RibbonButton icon={<Italic className="w-3.5 h-3.5"/>} onClick={() => execCmd('italic')} title="Italic" active={activeFormats.italic} />
                        <RibbonButton icon={<Underline className="w-3.5 h-3.5"/>} onClick={() => execCmd('underline')} title="Underline" active={activeFormats.underline} />
                        <RibbonButton icon={<Strikethrough className="w-3.5 h-3.5"/>} onClick={() => execCmd('strikeThrough')} title="Strikethrough" />
                        <div className="w-px h-4 bg-slate-200 mx-0.5"></div>
                        <RibbonButton icon={<Subscript className="w-3.5 h-3.5"/>} onClick={() => execCmd('subscript')} title="Subscript" active={activeFormats.subscript} />
                        <RibbonButton icon={<Superscript className="w-3.5 h-3.5"/>} onClick={() => execCmd('superscript')} title="Superscript" active={activeFormats.superscript} />
                        <div className="w-px h-4 bg-slate-200 mx-0.5"></div>
                        <ColorPicker icon={<Type className="w-3.5 h-3.5"/>} defaultColor="#ef4444" onChange={c => execCmd('foreColor', c)} label="#ef4444" />
                        <ColorPicker icon={<Highlighter className="w-3.5 h-3.5"/>} defaultColor="#facc15" onChange={c => execCmd('hiliteColor', c)} label="#facc15" />
                     </div>
                  </div>
               </ToolbarGroup>

               <ToolbarGroup label="Paragraph">
                  <div className="flex flex-col gap-1">
                     <div className="flex gap-0.5">
                        <RibbonButton icon={<List className="w-3.5 h-3.5"/>} onClick={() => execCmd('insertUnorderedList')} title="Bullet List" active={activeFormats.insertUnorderedList} />
                        <RibbonButton icon={<ListOrdered className="w-3.5 h-3.5"/>} onClick={() => execCmd('insertOrderedList')} title="Numbered List" active={activeFormats.insertOrderedList} />
                        <div className="w-px h-4 bg-slate-200 mx-1"></div>
                        <RibbonButton icon={<Outdent className="w-3.5 h-3.5"/>} onClick={() => execCmd('outdent')} title="Decrease Indent" />
                        <RibbonButton icon={<Indent className="w-3.5 h-3.5"/>} onClick={() => execCmd('indent')} title="Increase Indent" />
                        <div className="w-px h-4 bg-slate-200 mx-1"></div>
                        <CustomSelect 
                            width="w-12"
                            value="1.15"
                            options={[
                                {label:'1.0',value:'1.0'},
                                {label:'1.15',value:'1.15'},
                                {label:'1.5',value:'1.5'},
                                {label:'2.0',value:'2.0'}
                            ]}
                            onChange={v => setLineHeight(v)}
                        />
                     </div>
                     <div className="flex gap-0.5">
                        <RibbonButton icon={<AlignLeft className="w-3.5 h-3.5"/>} onClick={() => execCmd('justifyLeft')} title="Left" active={activeFormats.justifyLeft} />
                        <RibbonButton icon={<AlignCenter className="w-3.5 h-3.5"/>} onClick={() => execCmd('justifyCenter')} title="Center" active={activeFormats.justifyCenter} />
                        <RibbonButton icon={<AlignRight className="w-3.5 h-3.5"/>} onClick={() => execCmd('justifyRight')} title="Right" active={activeFormats.justifyRight} />
                        <RibbonButton icon={<AlignJustify className="w-3.5 h-3.5"/>} onClick={() => execCmd('justifyFull')} title="Justify" />
                     </div>
                  </div>
               </ToolbarGroup>

               <ToolbarGroup label="Styles">
                  <div className="grid grid-cols-2 gap-1 h-full">
                     <button onMouseDown={e => { e.preventDefault(); execCmd('formatBlock', '<h1>') }} className="px-2 py-1 text-left hover:bg-slate-100 rounded">
                        <span className="text-lg font-bold block leading-none">Title</span>
                        <span className="text-[9px] text-slate-400">Heading 1</span>
                     </button>
                     <button onMouseDown={e => { e.preventDefault(); execCmd('formatBlock', '<h2>') }} className="px-2 py-1 text-left hover:bg-slate-100 rounded">
                        <span className="text-sm font-bold block leading-none text-blue-800">Subtitle</span>
                        <span className="text-[9px] text-slate-400">Heading 2</span>
                     </button>
                     <button onMouseDown={e => { e.preventDefault(); execCmd('formatBlock', '<p>') }} className="px-2 py-1 text-left hover:bg-slate-100 rounded col-span-2">
                        <span className="text-xs block leading-none">Normal Paragraph</span>
                     </button>
                  </div>
               </ToolbarGroup>

               <ToolbarGroup label="Editing">
                  <RibbonButton icon={<BookOpen className="w-5 h-5 text-blue-600"/>} large label="Structure" onClick={() => setLeftOpen(!leftOpen)} active={leftOpen} />
               </ToolbarGroup>
             </>
           )}

           {/* INSERT TAB */}
           {ribbonTab === 'insert' && (
              <>
               <ToolbarGroup label="Pages">
                  <RibbonButton icon={<FileText className="w-6 h-6 text-slate-600"/>} large label="Page Break" onClick={() => execCmd('insertHTML', '<div style="page-break-after: always; border-top: 2px dashed #CBD5E1; margin: 40px 0;"></div>')} />
               </ToolbarGroup>
               <ToolbarGroup label="Tables">
                  <RibbonButton icon={<TableIcon className="w-6 h-6 text-slate-600"/>} large label="Table" onClick={insertTable} />
               </ToolbarGroup>
               <ToolbarGroup label="Media">
                  <RibbonButton icon={<ImageIcon className="w-6 h-6 text-slate-600"/>} large label="Picture" onClick={insertImagePlaceholder} />
               </ToolbarGroup>
               <ToolbarGroup label="Links">
                  <RibbonButton icon={<LinkIcon className="w-6 h-6 text-slate-600"/>} large label="Link" onClick={insertLink} />
               </ToolbarGroup>
               <ToolbarGroup label="Citations">
                  <RibbonButton icon={<BookOpen className="w-6 h-6 text-indigo-600"/>} large label="Cite Paper" onClick={() => { setSidebarTab('citations'); setRightOpen(true); }} />
               </ToolbarGroup>
              </>
           )}

           {/* LAYOUT TAB */}
           {ribbonTab === 'layout' && (
              <>
               <ToolbarGroup label="Page Setup">
                  <RibbonButton icon={<Layout className="w-6 h-6 text-slate-600"/>} large label="Margins" onClick={() => {}} />
                  <RibbonButton icon={<FileText className="w-6 h-6 text-slate-600"/>} large label="Orientation" onClick={() => {}} />
                  <RibbonButton icon={<Columns className="w-6 h-6 text-slate-600"/>} large label="Columns" onClick={() => {}} />
               </ToolbarGroup>
               <ToolbarGroup label="Paragraph">
                  <div className="flex flex-col gap-1">
                     <div className="flex items-center gap-2 text-[10px] text-slate-500">
                        <span>Line Spacing:</span>
                        <CustomSelect 
                           width="w-20"
                           value="1.5"
                           options={[{label:'1.0',value:'1'},{label:'1.15',value:'1.15'},{label:'1.5',value:'1.5'},{label:'2.0',value:'2'}]}
                           onChange={v => setLineHeight(v)}
                        />
                     </div>
                     <div className="flex items-center gap-2 text-[10px] text-slate-500">
                        <span>Before:</span>
                        <input type="number" className="w-10 border rounded px-1" defaultValue={0} />
                        <span>After:</span>
                        <input type="number" className="w-10 border rounded px-1" defaultValue={10} />
                     </div>
                  </div>
               </ToolbarGroup>
              </>
           )}

           {/* REVIEW TAB */}
           {ribbonTab === 'review' && (
              <>
               <ToolbarGroup label="Proofing">
                   <RibbonButton icon={<Check className="w-6 h-6 text-emerald-600"/>} large label="Spelling" onClick={() => handleReview('clarity')} />
               </ToolbarGroup>
               <ToolbarGroup label="Comments">
                   <RibbonButton icon={<MessageSquarePlus className="w-6 h-6 text-blue-600"/>} large label="New Comment" onClick={addComment} />
                   <RibbonButton icon={<MessageSquare className="w-6 h-6 text-slate-600"/>} large label="Show Comments" onClick={() => { setSidebarTab('comments'); setRightOpen(true); }} />
               </ToolbarGroup>
               <ToolbarGroup label="AI Analysis">
                   <div className="flex gap-2">
                      <button onClick={() => handleReview('gcp')} className="flex flex-col items-center justify-center p-2 hover:bg-slate-50 rounded">
                         <ShieldCheck className="w-5 h-5 text-indigo-600 mb-1" />
                         <span className="text-[10px]">GCP Audit</span>
                      </button>
                      <button onClick={() => handleReview('consistency')} className="flex flex-col items-center justify-center p-2 hover:bg-slate-50 rounded">
                         <Layout className="w-5 h-5 text-indigo-600 mb-1" />
                         <span className="text-[10px]">Consistency</span>
                      </button>
                   </div>
               </ToolbarGroup>
              </>
           )}

           {/* VIEW TAB */}
           {ribbonTab === 'view' && (
              <>
               <ToolbarGroup label="Views">
                  <RibbonButton icon={<FileText className="w-6 h-6 text-slate-600"/>} large label="Print Layout" onClick={() => setViewMode('section')} active={viewMode === 'section'} />
                  <RibbonButton icon={<Layout className="w-6 h-6 text-slate-600"/>} large label="Full Document" onClick={() => setViewMode('document')} active={viewMode === 'document'} />
               </ToolbarGroup>
               <ToolbarGroup label="Show">
                  <div className="flex flex-col gap-2 p-2">
                     <label className="flex items-center gap-2 text-xs"><input type="checkbox" checked={leftOpen} onChange={() => setLeftOpen(!leftOpen)} /> Navigation Pane</label>
                     <label className="flex items-center gap-2 text-xs"><input type="checkbox" checked={rightOpen} onChange={() => setRightOpen(!rightOpen)} /> Inspector Panel</label>
                  </div>
               </ToolbarGroup>
               <ToolbarGroup label="Zoom">
                  <RibbonButton icon={<Eye className="w-6 h-6 text-slate-600"/>} large label="100%" onClick={() => {}} />
               </ToolbarGroup>
              </>
           )}

        </div>
      </div>

      {/* 3. MAIN CONTENT AREA */}
      <div className="flex-1 flex overflow-hidden relative">
        
        {/* LEFT SIDEBAR (Navigation) */}
        <div className={`bg-[#F8F9FA] border-r flex flex-col transition-all duration-300 ${leftOpen ? 'w-64' : 'w-0 overflow-hidden'}`}>
           <div className="p-3 bg-white border-b font-bold text-xs text-slate-600 uppercase tracking-wider flex justify-between items-center shadow-sm z-10">
             <span>Navigation</span>
             <div className="flex gap-1">
                <button 
                    onClick={() => setSelectionMode(!selectionMode)} 
                    className={`p-1 rounded ${selectionMode ? 'bg-blue-100 text-blue-600' : 'hover:bg-slate-100 text-slate-500'}`}
                    title="Toggle Selection Mode"
                >
                    <CheckCircle className="w-3.5 h-3.5"/>
                </button>
                {selectionMode && (
                    <button 
                        onClick={handleSelectAll} 
                        className="p-1 rounded hover:bg-slate-100 text-slate-500"
                        title="Select All"
                    >
                        <List className="w-3.5 h-3.5"/>
                    </button>
                )}
                <button onClick={() => {
                    const t = prompt("Section Title:"); 
                    if(t) setDoc(d => ({...d, docTree: [...d.docTree, {id: Math.random().toString(36).substr(2,9), title: t, type: 'section', children: []}]}))
                }} className="hover:bg-slate-100 p-1 rounded"><Plus className="w-3.5 h-3.5"/></button>
             </div>
           </div>
           <div className="flex-1 overflow-y-auto p-2 custom-scrollbar">
              {doc.docTree.map(node => (
                <NodeItem 
                  key={node.id} 
                  node={node} 
                  activeNodeId={activeNodeId} 
                  hoverNodeId={hoverNodeId}
                  docData={doc.docData}
                  selectionMode={selectionMode}
                  selectedIds={batchSelectedIds}
                  onHover={setHoverNodeId}
                  onActivate={handleNodeSelect}
                  onAdd={() => {}} 
                  onRename={() => {}} 
                  onDelete={() => {}}
                  onToggleSelect={toggleSelection}
                />
              ))}
           </div>
        </div>

        {/* CENTER (Document Page) */}
        <div 
           ref={centerAreaRef} 
           onScroll={handleScroll}
           className="flex-1 overflow-auto bg-[#EBECEF] flex justify-center p-8 cursor-text relative custom-scrollbar" 
           onClick={() => editorRef.current?.focus()}
        >
           
           {viewMode === 'document' ? (
             <div className="flex flex-col items-center w-full gap-8 pb-20">
                {allNodes.map((node, idx) => (
                   <div 
                       key={node.id} 
                       className="w-[816px] bg-white shadow-lg p-[96px] min-h-[1056px] relative flex flex-col"
                       style={{
                           backgroundImage: `linear-gradient(to bottom, transparent 1055px, #CBD5E1 1055px, #CBD5E1 1056px, transparent 1056px)`,
                           backgroundSize: '100% 1056px',
                       }}
                   >
                      <h2 className="text-2xl font-serif font-bold mb-6 text-slate-900 border-b pb-2">{idx + 1}. {node.title}</h2>
                      <div 
                         contentEditable 
                         suppressContentEditableWarning
                         onBlur={(e) => {
                             const content = e.currentTarget.innerHTML;
                             setDoc(prev => ({ ...prev, docData: { ...prev.docData, [node.id]: content } }));
                         }}
                         dangerouslySetInnerHTML={{ __html: doc.docData[node.id] || '' }}
                         className="outline-none text-[12pt] font-serif leading-relaxed text-slate-900 flex-1"
                      />
                   </div>
                ))}
             </div>
           ) : activeNode ? (
             <div className="flex flex-col items-center w-full pb-20">
                
                {/* The Page Container - Continuous Sheet with Visual Page Breaks */}
                <div 
                   className="w-[816px] bg-white shadow-[0_4px_20px_rgba(0,0,0,0.15)] transition-all relative flex flex-col mb-10 print:shadow-none print:w-full"
                   style={{
                      // Visual page breaks every approx 1056px (approx A4 height at screen DPI)
                      backgroundImage: `linear-gradient(to bottom, transparent 1055px, #CBD5E1 1055px, #CBD5E1 1056px, transparent 1056px)`,
                      backgroundSize: '100% 1056px',
                      minHeight: '1056px'
                   }}
                >
                   
                   {/* Top Margin of Page 1 */}
                   <div className="h-[96px] w-full cursor-default" onMouseDown={e => e.preventDefault()}></div> 

                   {/* Content Area */}
                   <div className="px-[96px] flex-1">
                      {/* Section Title */}
                      <h1 className="text-3xl font-serif font-bold text-slate-900 mb-6 pb-2 border-b border-slate-100">{activeNode.title}</h1>

                      {/* Editable Div */}
                      <div 
                        ref={editorRef}
                        className="outline-none text-[12pt] font-serif leading-relaxed text-slate-900 min-h-[600px] selection:bg-blue-100 selection:text-blue-900 pb-[96px]"
                        contentEditable
                        suppressContentEditableWarning
                        onBlur={handleContentChange}
                        onKeyDown={(e) => {
                           if (e.key === 'Tab') {
                              e.preventDefault();
                              execCmd('insertHTML', '&nbsp;&nbsp;&nbsp;&nbsp;');
                           }
                        }}
                      />
                   </div>
                </div>

             </div>
           ) : (
             <div className="flex flex-col items-center justify-center text-slate-400 h-full">
               <FileText className="w-16 h-16 opacity-10 mb-4" />
               <p className="font-medium">Select a section to start editing</p>
             </div>
           )}
        </div>

        {/* RIGHT SIDEBAR (Inspector) */}
        <div className={`bg-white border-l flex flex-col transition-all duration-300 ${rightOpen ? 'w-80' : 'w-0 overflow-hidden'} shadow-xl z-20`}>
           <div className="flex border-b text-xs font-bold text-slate-500 bg-slate-50">
             <button onClick={() => setSidebarTab('info')} className={`flex-1 p-3 ${sidebarTab === 'info' ? 'bg-white text-blue-600 border-t-2 border-blue-600' : 'hover:bg-slate-100'}`}>Info</button>
             <button onClick={() => setSidebarTab('comments')} className={`flex-1 p-3 ${sidebarTab === 'comments' ? 'bg-white text-blue-600 border-t-2 border-blue-600' : 'hover:bg-slate-100'}`}>Comments</button>
             <button onClick={() => setSidebarTab('review')} className={`flex-1 p-3 ${sidebarTab === 'review' ? 'bg-white text-blue-600 border-t-2 border-blue-600' : 'hover:bg-slate-100'}`}>Review</button>
             <button onClick={() => setSidebarTab('citations')} className={`flex-1 p-3 ${sidebarTab === 'citations' ? 'bg-white text-blue-600 border-t-2 border-blue-600' : 'hover:bg-slate-100'}`}>Cite</button>
             <button onClick={() => setSidebarTab('batch')} className={`flex-1 p-3 ${sidebarTab === 'batch' ? 'bg-white text-blue-600 border-t-2 border-blue-600' : 'hover:bg-slate-100'}`}>Batch</button>
           </div>

           <div className="flex-1 overflow-y-auto p-4 custom-scrollbar">
              {sidebarTab === 'info' && (
                <div className="space-y-6">
                   <div>
                      <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1"><Zap className="w-3 h-3"/> Project Data</h4>
                      <div className="space-y-2">
                        {['studyPhase', 'sampleSize', 'duration', 'trialId'].map(k => (
                          <div key={k} className="bg-slate-50 p-2 rounded border border-slate-100">
                            <span className="text-[9px] text-slate-400 uppercase block">{k.replace(/([A-Z])/g, ' $1').trim()}</span>
                            <span className="text-xs font-medium text-slate-700">{project.variables[k] || 'N/A'}</span>
                          </div>
                        ))}
                      </div>
                   </div>
                   <div>
                      <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1"><BookOpen className="w-3 h-3"/> References</h4>
                      <div className="space-y-1">
                        {kbItems.length === 0 && <p className="text-xs text-slate-400 italic">No KB documents.</p>}
                        {kbItems.map(item => (
                          <label key={item.id} className="flex items-center gap-2 text-xs p-1.5 hover:bg-slate-50 rounded cursor-pointer border border-transparent hover:border-slate-100">
                            <input type="checkbox" checked={selectedKbIds.has(item.id)} onChange={e => {
                               const next = new Set(selectedKbIds);
                               e.target.checked ? next.add(item.id) : next.delete(item.id);
                               setSelectedKbIds(next);
                            }} className="rounded text-blue-600 focus:ring-0" />
                            <span className="truncate flex-1">{item.name}</span>
                          </label>
                        ))}
                      </div>
                   </div>
                </div>
              )}

              {sidebarTab === 'citations' && (
                <div className="space-y-4">
                   <h3 className="font-bold text-slate-700 text-sm">Academic Citations</h3>
                   <div className="space-y-3">
                      <div className="flex bg-slate-100 p-1 rounded-lg">
                         <button 
                            onClick={() => setCitationSource('pubmed')}
                            className={`flex-1 py-1 text-[10px] font-bold rounded ${citationSource === 'pubmed' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-500'}`}
                         >PubMed</button>
                         <button 
                            onClick={() => setCitationSource('clinicaltrials')}
                            className={`flex-1 py-1 text-[10px] font-bold rounded ${citationSource === 'clinicaltrials' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-500'}`}
                         >ClinicalTrials.gov</button>
                      </div>
                      <div className="relative">
                         <input 
                            type="text"
                            value={citationQuery}
                            onChange={(e) => setCitationQuery(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleCitationSearch()}
                            placeholder={`Search ${citationSource === 'pubmed' ? 'PubMed...' : 'Trials...'}`}
                            className="w-full text-xs p-2 pr-8 border rounded-lg focus:ring-1 focus:ring-blue-500 outline-none"
                         />
                         <button 
                            onClick={handleCitationSearch}
                            className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-blue-500"
                         >
                            {searchingCitations ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />}
                         </button>
                      </div>
                   </div>

                   <div className="space-y-3 mt-4">
                      {searchingCitations && (
                         <div className="text-center py-8">
                            <Loader2 className="w-6 h-6 animate-spin mx-auto text-blue-500 mb-2" />
                            <p className="text-[10px] text-slate-400">Searching academic databases...</p>
                         </div>
                      )}

                      {!searchingCitations && citationResults.length === 0 && citationQuery && (
                         <p className="text-center py-8 text-xs text-slate-400 italic">No results found.</p>
                      )}

                      {!searchingCitations && citationResults.map(res => (
                         <div key={res.id} className="bg-white border border-slate-200 rounded-lg p-3 hover:border-blue-300 transition-colors group shadow-sm">
                            <h4 className="text-xs font-bold text-slate-800 line-clamp-2 mb-1 group-hover:text-blue-700">{res.title}</h4>
                            <div className="flex flex-wrap gap-x-2 gap-y-1 mb-2">
                               <span className="text-[9px] text-slate-500 font-medium">{res.authors?.[0]} et al.</span>
                               <span className="text-[9px] text-slate-400">{res.year}</span>
                               <span className="text-[9px] bg-slate-100 px-1 rounded text-slate-500 uppercase font-bold">{res.source}</span>
                            </div>
                            <button 
                               onClick={() => insertCitation(res)}
                               className="w-full py-1.5 bg-blue-50 text-blue-600 text-[10px] font-bold rounded hover:bg-blue-600 hover:text-white transition-all flex items-center justify-center gap-1"
                            >
                               <Plus className="w-3 h-3" /> Insert Citation
                            </button>
                         </div>
                      ))}
                   </div>
                </div>
              )}

              {sidebarTab === 'batch' && (
                <div className="space-y-4">
                   <h3 className="font-bold text-slate-700 text-sm">Batch Find & Replace</h3>
                   
                   <div className="bg-slate-50 p-3 rounded border border-slate-100 space-y-3">
                       <div>
                           <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Find</label>
                           <input 
                               type="text" 
                               value={findText} 
                               onChange={e => setFindText(e.target.value)} 
                               className="w-full text-xs p-2 border rounded focus:ring-1 focus:ring-blue-500 outline-none"
                               placeholder="Text to find..."
                           />
                       </div>
                       <div>
                           <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Replace With</label>
                           <input 
                               type="text" 
                               value={replaceText} 
                               onChange={e => setReplaceText(e.target.value)} 
                               className="w-full text-xs p-2 border rounded focus:ring-1 focus:ring-blue-500 outline-none"
                               placeholder="Replacement text..."
                           />
                       </div>
                       <button 
                           onClick={handleBatchUpdate}
                           className="w-full bg-blue-600 text-white text-xs font-bold py-2 rounded hover:bg-blue-700 transition-colors"
                       >
                           Replace in Selected
                       </button>
                   </div>

                   <div>
                       <div className="flex justify-between items-center mb-2">
                           <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Target Sections</h4>
                           <div className="flex gap-2">
                               <button onClick={() => setBatchSelectedIds(new Set(allNodes.map(n => n.id)))} className="text-[10px] text-blue-600 hover:underline">All</button>
                               <button onClick={() => setBatchSelectedIds(new Set())} className="text-[10px] text-slate-400 hover:underline">None</button>
                           </div>
                       </div>
                       <div className="border rounded max-h-[300px] overflow-y-auto bg-white">
                           {allNodes.map(node => (
                               <label key={node.id} className="flex items-center gap-2 p-2 hover:bg-slate-50 border-b border-slate-50 last:border-0 cursor-pointer">
                                   <input 
                                       type="checkbox" 
                                       checked={batchSelectedIds.has(node.id)}
                                       onChange={e => {
                                           const next = new Set(batchSelectedIds);
                                           e.target.checked ? next.add(node.id) : next.delete(node.id);
                                           setBatchSelectedIds(next);
                                       }}
                                       className="rounded text-blue-600 focus:ring-0"
                                   />
                                   <span className="text-xs truncate text-slate-700">{node.title}</span>
                               </label>
                           ))}
                       </div>
                   </div>
                </div>
              )}

              {sidebarTab === 'comments' && (
                <div className="space-y-4">
                   <div className="flex justify-between items-center">
                     <h3 className="font-bold text-slate-700 text-sm">Comments ({activeComments.length})</h3>
                     <button onClick={addComment} className="text-xs text-blue-600 hover:underline flex items-center gap-1"><Plus className="w-3 h-3"/> Add</button>
                   </div>
                   
                   {activeComments.length === 0 && <p className="text-xs text-slate-400 italic text-center py-4">No comments on this section.</p>}
                   
                   <div className="space-y-3">
                     {activeComments.map(c => (
                       <div 
                          key={c.id} 
                          onMouseEnter={() => setHoveredCommentId(c.id)}
                          onMouseLeave={() => setHoveredCommentId(null)}
                          onClick={() => scrollToComment(c.id)}
                          className={`
                             cursor-pointer transition-all p-3 rounded-lg border shadow-sm
                             ${hoveredCommentId === c.id ? 'bg-blue-50 border-blue-200 ring-1 ring-blue-100' : 'bg-yellow-50/50 border-yellow-100 hover:bg-yellow-50'}
                          `}
                       >
                          <div className="flex justify-between items-start mb-1">
                             <div className="flex items-center gap-2">
                                <div className="w-5 h-5 rounded-full bg-blue-100 flex items-center justify-center text-[10px] font-bold text-blue-600">
                                   {c.author.charAt(0)}
                                </div>
                                <span className="font-bold text-xs text-slate-700">{c.author}</span>
                             </div>
                             <span className="text-[9px] text-slate-400">{new Date(c.timestamp).toLocaleTimeString()}</span>
                          </div>
                          <div className="mb-2 text-[11px] text-slate-500 border-l-2 border-yellow-300 pl-2 italic line-clamp-2 bg-white/50 p-1 rounded">
                             "{c.selectedText}"
                          </div>
                          <p className="text-xs text-slate-800 leading-relaxed">{c.text}</p>
                          <div className="mt-3 flex justify-end gap-2 pt-2 border-t border-slate-100">
                             <button 
                                onClick={(e) => { e.stopPropagation(); deleteComment(c.id); }} 
                                className="text-[10px] text-emerald-600 hover:text-emerald-700 uppercase font-bold tracking-wide flex items-center gap-1"
                             >
                                <Check className="w-3 h-3"/> Resolve
                             </button>
                          </div>
                       </div>
                     ))}
                   </div>
                </div>
              )}

              {sidebarTab === 'review' && (
                <div>
                   <h3 className="font-bold text-slate-700 text-sm">AI Quality Review</h3>
                   {critique && !reviewing && (
                      <button onClick={() => setCritique('')} className="text-[10px] text-slate-400 hover:text-slate-600 uppercase font-bold mt-1">Clear Results</button>
                   )}
                   
                   {!critique && !reviewing && (
                      <div className="bg-indigo-50 border border-indigo-100 p-4 rounded-xl text-center space-y-3 mt-4">
                         <Sparkles className="w-8 h-8 text-indigo-500 mx-auto opacity-50" />
                         <p className="text-xs text-indigo-900 font-medium">Select a review mode from the Ribbon to analyze your content for compliance, clarity, and consistency.</p>
                         <div className="grid grid-cols-1 gap-2">
                            <button onClick={() => handleReview('clarity')} className="text-[10px] bg-white border border-indigo-200 py-2 rounded-lg hover:bg-indigo-100 transition-colors font-bold text-indigo-700">Check Clarity & Tone</button>
                            <button onClick={() => handleReview('gcp')} className="text-[10px] bg-white border border-indigo-200 py-2 rounded-lg hover:bg-indigo-100 transition-colors font-bold text-indigo-700">GCP Compliance Audit</button>
                            <button onClick={() => handleReview('consistency')} className="text-[10px] bg-white border border-indigo-200 py-2 rounded-lg hover:bg-indigo-100 transition-colors font-bold text-indigo-700">Cross-Section Consistency</button>
                         </div>
                      </div>
                   )}

                   {reviewing && (
                      <div className="flex flex-col items-center justify-center py-12 space-y-4">
                         <div className="relative">
                            <Loader2 className="w-10 h-10 animate-spin text-indigo-500"/>
                            <Sparkles className="w-4 h-4 text-indigo-400 absolute -top-1 -right-1 animate-pulse" />
                         </div>
                         <div className="text-center">
                            <p className="text-xs font-bold text-slate-700">AI is analyzing...</p>
                            <p className="text-[10px] text-slate-400">Comparing against clinical standards</p>
                         </div>
                      </div>
                   )}

                   {critique && !reviewing && (
                      <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-300 mt-4">
                         <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
                            <div className="bg-slate-50 px-3 py-2 border-b flex items-center gap-2">
                               <ShieldCheck className="w-4 h-4 text-emerald-500" />
                               <span className="text-[10px] font-bold text-slate-600 uppercase tracking-wider">Analysis Results</span>
                            </div>
                            <div className="p-4 prose prose-sm prose-slate max-w-none">
                               <div className="text-xs text-slate-700 leading-relaxed whitespace-pre-wrap">
                                  {critique}
                                </div>
                            </div>
                         </div>
                         
                         <div className="bg-amber-50 border border-amber-100 p-3 rounded-lg flex gap-3">
                            <Zap className="w-5 h-5 text-amber-500 shrink-0" />
                            <div>
                               <p className="text-[10px] font-bold text-amber-900 uppercase">Recommendation</p>
                               <p className="text-[11px] text-amber-800">Review the points above and use the "Refine" tool in the Home tab to automatically address these suggestions.</p>
                            </div>
                         </div>
                      </div>
                   )}
                </div>
              )}
           </div>
        </div>

      </div>

      {/* 4. STATUS BAR */}
      <div className="h-6 bg-[#F3F4F6] border-t border-slate-300 text-slate-600 text-[10px] flex items-center px-4 justify-between shrink-0 select-none">
         <div className="flex gap-6">
           <span>Page {currentPage} of {pageCount}</span>
           <span>{doc.docData[activeNodeId || '']?.replace(/<[^>]*>/g, '').trim().split(/\s+/).length || 0} words</span>
           <span>English (US)</span>
         </div>
         <div className="flex gap-6">
           <span>{generating ? 'AI Writing...' : 'Ready'}</span>
           <div className="flex items-center gap-2">
              <div className="w-16 h-1.5 bg-slate-200 rounded-full overflow-hidden">
                 <div className="h-full bg-emerald-500 transition-all duration-500" style={{ width: `${completionStats.percent}%` }}></div>
              </div>
              <span>{completionStats.percent}% Complete</span>
           </div>
         </div>
      </div>

    </div>
  );
};

export default Workspace;