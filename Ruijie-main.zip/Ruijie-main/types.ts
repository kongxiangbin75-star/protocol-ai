export interface Project {
  id: string;
  projectName: string;
  variables: ClinicalVariables;
  documents: ClinicalDocument[];
  activityLog: ActivityLogItem[];
  createdAt: number;
  updatedAt: number;
}

export interface ActivityLogItem {
  id: string;
  action: string; // e.g., "Created Document", "Updated Status"
  target: string; // e.g., "Protocol v1"
  user: string;
  timestamp: number;
}

export interface DocumentVersion {
  id: string;
  name: string; // e.g., "Draft 0.1"
  timestamp: number;
  docData: Record<string, string>;
}

export interface Comment {
  id: string;
  author: string;
  text: string;
  selectedText: string;
  timestamp: number;
  resolved: boolean;
}

export interface ClinicalDocument {
  id: string;
  title: string;
  type: DocumentType;
  status: 'draft' | 'review' | 'qc' | 'final'; // Added QC
  assignee?: string; // New: Who is responsible?
  dueDate?: number;  // New: When is it due?
  priority?: 'low' | 'medium' | 'high'; // New: Urgency
  docTree: DocNode[];
  docData: Record<string, string>;
  comments?: Record<string, Comment[]>;
  versions: DocumentVersion[];
  updatedAt: number;
}

export type DocumentType = 
  // Trial Binder
  | 'protocol' | 'ib' | 'worksheet'
  // Subject Binder
  | 'icf' | 'diary' | 'participation_card' | 'ad'
  // Operation Binder
  | 'sap' | 'dmp' | 'cmp' | 'csr' | 'manual';

export interface ClinicalVariables {
  fullTitle: string;
  briefTitle: string;
  trialId: string;
  protocolVersionDate: string;
  studyPhase: string;
  trialDesign: string;
  objectives: string;
  studyEndpoints: string;
  inclusionCriteria: string;
  exclusionCriteria: string;
  sampleSize: string;
  targetPopulation: string;
  investigationalProduct: string;
  comparator: string;
  routesOfAdministration: string;
  statisticalAnalysis: string;
  duration: string;
  [key: string]: string;
}

export interface DocNode {
  id: string;
  title: string;
  type: 'section' | 'text';
  children?: DocNode[];
  number?: string;
  defaultContent?: string;
}

export interface KBItem {
  id: string;
  name: string;
  type: 'file' | 'folder';
  parentId: string | null;
  content?: string;
  createdAt: number;
}

export interface CustomTemplate {
  id: string;
  name: string;
  baseType: DocumentType;
  structure: DocNode[];
  createdAt: number;
}

export interface ApiConfig {
  apiKey: string;
  model: string;
  provider: 'Gemini' | 'Qwen' | 'Doubao' | 'OpenAI-Compatible';
  baseUrl?: string;
}

export interface Citation {
  id: string;
  source: 'pubmed' | 'clinicaltrials';
  title: string;
  authors?: string[];
  journal?: string;
  year?: string;
  url: string;
  doi?: string;
  abstract?: string;
}
